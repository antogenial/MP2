package ch.epfl.cs107.icoop.actor;

import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;
import ch.epfl.cs107.play.engine.actor.Actor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Transform;
import ch.epfl.cs107.play.math.Vector;

import static ch.epfl.cs107.play.math.DiscreteCoordinates.distanceBetween;

public class CenterOfMass implements Actor {

    private final Actor[] actors;

    public CenterOfMass(Actor actor, Actor... restOfActors) {
        this.actors = new Actor[restOfActors.length + 1];
        actors[0] = actor;
        System.arraycopy(restOfActors, 0, this.actors, 1, restOfActors.length);
    }

    @Override
    public Vector getPosition() {
        Vector position = Vector.ZERO;
        for (Actor actor : actors) {
            position = position.add(actor.getPosition());
        }
        return position.mul(1f / actors.length);
    }

    @Override
    public Transform getTransform() {
        return Transform.I.translated(getPosition());
    }

    @Override
    public Vector getVelocity() {
        Vector velocity = Vector.ZERO;
        for (Actor actor : actors) {
            velocity = velocity.add(actor.getVelocity());
        }
        return velocity.mul(1f / actors.length);
    }


    public float distanceWithPlayer(ICoopPlayer player){ // compute distance with two player
        Vector vectorCoordinates = getPosition();
        int x = (int)vectorCoordinates.x, y = (int)vectorCoordinates.y;
        return distanceBetween(new DiscreteCoordinates(x, y), player.getCurrentMainCellCoordinates());
    }

    public float averageDistance(ICoopPlayer... players){ // compute the average distance between x players
        float distanceTotal = 0;
        for (ICoopPlayer player : players) {  // iterate players and update center of mass with the next player of the list
            distanceTotal += distanceWithPlayer(player);
        }
        return distanceTotal / (float)  players.length;
    }
}
