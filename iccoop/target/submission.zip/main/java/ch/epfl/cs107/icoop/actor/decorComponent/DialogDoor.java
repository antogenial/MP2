package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.icoop.actor.DialogOwner;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Dialog;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;

public class DialogDoor extends Door implements DialogOwner {
    private Dialog dialog;
    private String[] dialogNames = new String[2];
    private Dialog[] dialogs = new Dialog[2];
    private boolean collision, resetCollision = false;
    //private Sprite sprite = new Animation()

    public DialogDoor(String destination, Logic signal, DiscreteCoordinates[] spawnCoordinates, Area area, DiscreteCoordinates position, String dialogNameOn, String dialogNameOff) {
        super(destination, signal, spawnCoordinates, area, position);
        dialogNames[0] = dialogNameOff;
        dialogNames[1] = dialogNameOn;
        initDialog();
        chooseDialog();
    }

    // Actor overrides

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        if (!collision && dialog.isCompleted()) initDialog();

        if (resetCollision){
            collision = false;
        }
        resetCollision = true;
    }

    // Interactable overrides

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this, isCellInteraction);
    }


    private void chooseDialog(){
        dialog = dialogs[(int)getSignal().getIntensity()]; // getIntensity() = 0 if isOff and 1 if isOn
    }

    public Dialog getDialog() {
        chooseDialog();
        return dialog;
    }

    private void initDialog(){
        for (int i = 0; i < dialogNames.length; i++) {
            dialogs[i] = new Dialog(dialogNames[i]);
        }
    }

    public void isColliding(){
        collision = true;
        resetCollision = false;
    }


}
