package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.signal.logic.Logic;

import java.util.ArrayList;
import java.util.List;

public class Door extends AreaEntity {

    private String destination;
    private DiscreteCoordinates[] spawnCoordinates = new DiscreteCoordinates[2];
    private ArrayList<DiscreteCoordinates> usedCells = new ArrayList<>();
    private Logic signal;

    // Consructors
    public Door (String destination, Logic signal, DiscreteCoordinates[] spawnCoordinates, Area area, DiscreteCoordinates position) {
        this(destination, signal, spawnCoordinates, area, position, position);
    }

    public Door (String destination, Logic signal, DiscreteCoordinates[] spawnCoordinates, Area area, DiscreteCoordinates position, DiscreteCoordinates... usedcells) {
        super(area, Orientation.UP, position);
        this.destination = destination;
        this.spawnCoordinates = spawnCoordinates;
        this.signal = signal;

        boolean isIn = false;
        for (DiscreteCoordinates cell : usedcells) {
            if(cell.equals(position)) {
                isIn = true;
            }
            this.usedCells.add(cell);
        }

        if (!isIn){
            this.usedCells.addFirst(position);
        }
    }

    // Getters
    public Logic getSignal() {
        return signal;
    }

    public String getDestination() {
        return destination;
    }

    public DiscreteCoordinates[] getSpawnCoordinates() {
        return spawnCoordinates;
    }

    // Setters
    public void setSignal(Logic signal) {
        this.signal = signal;
    }

    // Interactable overrides
    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return  usedCells;
    }
    @Override
    public boolean takeCellSpace() {
        return false;
    }
    @Override
    public boolean isCellInteractable() {
        return true;
    }
    @Override
    public boolean isViewInteractable() {
        return false;
    }
    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this, isCellInteraction);
    }
}
