package ch.epfl.cs107.icoop.actor.characters;

import ch.epfl.cs107.icoop.Timer;
import ch.epfl.cs107.play.areagame.actor.Interactor;
import ch.epfl.cs107.play.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.Positionable;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Button;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.icoop.actor.ElementEntity.ElementType;

import java.util.Collections;
import java.util.List;

public abstract class Foe extends MovableAreaEntity implements Interactor{

    private final static float IMMUNITY_PERIOD = 2;
    private Timer immunityTimer = new Timer(IMMUNITY_PERIOD);
    private boolean isUnvulnerable = false;
    private ElementType[] vulnerability;

    public Foe(Area owner, Orientation orientation, DiscreteCoordinates coordinates, ElementType... vulnerability) {
        super(owner, orientation, coordinates);
        this.vulnerability = vulnerability.clone();
    }

    // minimals getters
    public abstract int getMAX_LIFE();
    public abstract int getHealthPoint();

    // class getters
    public float getIMMUNITY_PERIOD(){
        return IMMUNITY_PERIOD;
    }
    public boolean getIsUnvulnerable(){
        return isUnvulnerable;
    }
    public Timer getImmunityTimer(){
        return immunityTimer;
    }

    //class setters
    public void setIsUnvulnerable(boolean isUnvulnerable){
        this.isUnvulnerable = isUnvulnerable;
    }

    // interaction management
    public abstract void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction);
    public abstract boolean wantsCellInteraction();
    public abstract boolean wantsViewInteraction();
    public abstract boolean interactWith();
    public boolean takeCellSpace(){
        return true;
    }
    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }

    // health management
    public abstract void takeDamage(int damage);
    public abstract void takeDamage(int damage, ElementType type);
    public abstract void addHealth(int hp);
    public abstract void addHealth(int hp, ElementType type);
    public abstract boolean isDead();
    public boolean isVulnerableTo(ElementType type){
        for (ElementType vuln : vulnerability) {
            if (type == vuln) return true;
        }
        return false;
    }

    // other abstract
    public abstract void draw(Canvas canvas);

    // common functions
    public void update(float deltaTime){
        super.update(deltaTime);
    }

    protected void removeFromArea(){
        getOwnerArea().unregisterActor(this);
    }

    public static Animation construcDeathAnimation(Positionable parent) {
        return new Animation("icoop/vanish", 7, 2, 2, parent, 32, 32,
                new Vector(-0.5f, 0f), 24/7, false);
    }
}
