package ch.epfl.cs107.icoop.handler;

import ch.epfl.cs107.play.areagame.handler.Inventory;
import ch.epfl.cs107.play.areagame.handler.InventoryItem;

public class ICoopInventory extends Inventory {

    public ICoopInventory(String... pocketNames) { // Creates an ICoopInventory
        super(pocketNames);
    }
}
