package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;

import java.util.Collections;
import java.util.List;

public class Obstacle extends AreaEntity {

    // animation variable
    private Sprite sprite;

    public Obstacle(Area area, DiscreteCoordinates position) {
        this(area, position, "rock.2");
    }
    public Obstacle(Area area, DiscreteCoordinates position, String imageName) {
        super(area, Orientation.UP, position);
        // animation init
        sprite = new Sprite(imageName, 1f, 1f, this);
    }

    public void draw(ch.epfl.cs107.play.window.Canvas canvas) {
        sprite.draw(canvas);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
    }

    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }

    @Override
    public boolean takeCellSpace() {
        return true;
    }

    @Override
    public boolean isCellInteractable() {
        return true; // instructions ask false but true for be able to stop elemental balls
    }

    @Override
    public boolean isViewInteractable() {
        return false;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }
}

