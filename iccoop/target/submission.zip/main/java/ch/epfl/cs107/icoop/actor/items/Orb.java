package ch.epfl.cs107.icoop.actor.items;

import ch.epfl.cs107.icoop.actor.DialogOwner;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.engine.actor.Dialog;
import ch.epfl.cs107.play.engine.actor.RPGSprite;
import ch.epfl.cs107.play.engine.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.window.Canvas;

public class Orb extends ElementalItem implements DialogOwner {

    // animation variables
    private final static int ANIMATION_DURATION = 24;
    private final static int ANIMATION_FRAMES = 6;
    private final static int CASE_SIZE = 32;
    private Animation sprite;
    // dialog
    private Dialog orbDialog;

    public Orb(Area area, DiscreteCoordinates position, ElementType type) {
        super(area, position, Orientation.UP, false, type);
        // type adaptation
        String dialogName = null;
        int spriteYDelta = CASE_SIZE;
        switch (type) {
            case FIRE: {
                dialogName = "orb_fire_msg";
                spriteYDelta *= 2;
                break;
            }
            case WATER: {
                dialogName = "orb_water_msg";
                spriteYDelta *= 0;
                break;
            }
            default: {
                throw new IllegalArgumentException("Incorrect type name : " + type);
            }
        }
        // attributes
        orbDialog = new Dialog(dialogName);

        // animation
        final Sprite[] sprites = new Sprite[ANIMATION_FRAMES];
        for (int i = 0; i < ANIMATION_FRAMES; ++i) {
            sprites[i] = new RPGSprite("icoop/orb", 1, 1, this,
                    new RegionOfInterest(i * CASE_SIZE, spriteYDelta, CASE_SIZE, CASE_SIZE));
        }
        sprite = new Animation(ANIMATION_DURATION / ANIMATION_FRAMES , sprites);
    }

    public Dialog getDialog() {
        return orbDialog;
    }

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        sprite.update(deltaTime);
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }
}
