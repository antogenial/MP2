package ch.epfl.cs107.icoop;


import ch.epfl.cs107.icoop.actor.CenterOfMass;
import ch.epfl.cs107.icoop.actor.ElementEntity;
import ch.epfl.cs107.icoop.actor.decorComponent.Door;
import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;
import ch.epfl.cs107.icoop.area.*;
import ch.epfl.cs107.icoop.handler.DialogHandler;
import ch.epfl.cs107.play.areagame.AreaGame;
import ch.epfl.cs107.play.engine.actor.Dialog;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.signal.logic.And;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Window;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ICoop extends AreaGame implements DialogHandler {

    private ICoopPlayer[] players = new ICoopPlayer[2];
    private CenterOfMass playerCenter;
    private int areaIndex;
    private Dialog activeDialog = null;
    private Logic gameOverSignal;
    private ArrayList<String> areasName = new ArrayList<>(List.of("Spawn", "OrbWay", "Maze", "Arena", "SanctumEntrance", "Sanctum"));
    private ArrayList<ICoopArea> areas = new ArrayList<>();
    private ArrayList<String> nameOfZonesToComplete = new ArrayList<>(List.of("Spawn", "Maze", "Arena")); // OrbWay don't need to be complete

    // "Game" overrides

    @Override
    public boolean begin(Window window, FileSystem fileSystem) {
        if (super.begin(window, fileSystem)) {
            createAreas();
            areaIndex = 3;
            initArea(areasName.get(areaIndex));
            endGameCompute();
            return true;
        }
        else {
            return false;
        }
    }
    @Override
    public void update(float deltaTime) {
        endGameCompute();
        Keyboard keyboard = getCurrentArea().getKeyboard();
        if (activeDialog != null) {
            activeDialog.draw(getWindow());
            if (keyboard.get(KeyBindings.NEXT_DIALOG).isPressed()) {
                activeDialog.update(deltaTime);
            }
            if (activeDialog.isCompleted()) {
                setActiveDialog(null);
            }
        }

        if (activeDialog == null) {
            super.update(deltaTime);
            ((ICoopArea)getCurrentArea()).setCameraScaleFactor(playerCenter.averageDistance(players));
            if (keyboard.get(KeyBindings.RESET_GAME).isPressed()) {
                begin(getWindow(), getFileSystem());
            } else if (keyboard.get(KeyBindings.RESET_AREA).isPressed()) {
                resetArea();
            }


            // health and door check
            for (ICoopPlayer player : players) {
                if (player.isDead()) {
                    resetArea();
                } else {
                    if (player.getDialog() != null) {
                        setActiveDialog(player.getDialog());
                    }
                    else if (player.getDoor() != null){// && player.getDialog() == null) {
                        switchArea(player);
                        player.setDoor(null);
                        super.update(deltaTime);
                    }
                }
            }
        }
    }
    @Override
    public String getTitle() {
        return "ICoop";
    }

    @Override
    public void end() {} // à garder ???

    // "DialogHandler" overrides

    @Override
    public void publish(Dialog dialog) {
        setActiveDialog(dialog);
    }

    // Private methods

    private void centerView(){
        getCurrentArea().setViewCandidate(playerCenter);
    }

    private void initArea(String areaKey) {
        ICoopArea area = (ICoopArea) setCurrentArea(areaKey, true);
        DiscreteCoordinates[] coords = area.getPlayerSpawnPositions();
        players[0] = new ICoopPlayer(area, Orientation.DOWN, coords[0], ElementEntity.ElementType.FIRE);
        players[1] = new ICoopPlayer(area, Orientation.DOWN, coords[1], ElementEntity.ElementType.WATER);
        ICoopPlayer[] sousTableau = Arrays.copyOfRange(players, 1, players.length);
        playerCenter = new CenterOfMass(players[0], sousTableau);
        for (int i = 0; i < players.length; i++) {
            players[i].enterArea(area, coords[i]);
        }
        centerView();
    }

    private void endGameCompute() {
        for (String s : nameOfZonesToComplete) {
            for (ICoopArea area : areas) {
                if (area.getTitle().equals(s)) {
                    if (s.equals(nameOfZonesToComplete.getFirst())) gameOverSignal = area;
                    else gameOverSignal = new And(gameOverSignal, area);
                }
            }
        }
    }

    private void createAreas() {
        areas.add(new Spawn(this));
        areas.add(new OrbWay());
        areas.add(new Maze());
        areas.add(new Arena());
        areas.add(new SanctumEntrance());
        areas.add(new Sanctum());
        for (ICoopArea area : areas) {
            addArea(area);
        }
    }

    // Public methods

    public void switchArea(ICoopPlayer player) {
        Door door = player.getDoor();
        for (int i = 0; i < players.length; i++) {    // unregistoring both actors is necessaryiiiiiiii to be sure that there are no conflicts
            players[i].leaveArea();
        }
        ICoopArea currentArea = (ICoopArea) setCurrentArea(door.getDestination(),false); // Transforme la nouvelle aire en un ICoopArea qui contient le comportement de l'aire
        for (int i = 0; i < players.length; i++) {
            players[i].enterArea(currentArea, door.getSpawnCoordinates()[i]);
        }
        centerView();

        Logic arenaSignal = areas.get(areasName.indexOf("Arena")); // get "arena" area
        ICoopArea spawn = areas.get(nameOfZonesToComplete.indexOf("Spawn")); // get "spawn" area
        spawn.setExternalLogic(arenaSignal);

    }

    public void resetArea() {
        initArea(getCurrentArea().getTitle());
    }

    public void setActiveDialog(Dialog dialog){
        this.activeDialog = dialog;
    }
}
