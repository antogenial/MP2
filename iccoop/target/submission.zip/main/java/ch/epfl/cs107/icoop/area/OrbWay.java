package ch.epfl.cs107.icoop.area;

import ch.epfl.cs107.icoop.actor.*;
import ch.epfl.cs107.icoop.actor.decorComponent.Door;
import ch.epfl.cs107.icoop.actor.decorComponent.ElementalWall;
import ch.epfl.cs107.icoop.actor.decorComponent.Mecanisme;
import ch.epfl.cs107.icoop.actor.decorComponent.PressurePlate;
import ch.epfl.cs107.icoop.actor.items.Heart;
import ch.epfl.cs107.icoop.actor.items.Orb;
import ch.epfl.cs107.play.engine.actor.Background;
import ch.epfl.cs107.play.engine.actor.Foreground;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.signal.logic.Logic;


public class OrbWay extends ICoopArea{

    private static final ElementEntity.ElementType FIRE = ElementEntity.ElementType.FIRE;
    private static final ElementEntity.ElementType WATER = ElementEntity.ElementType.WATER;
    protected final static DiscreteCoordinates[] playersSpawnPositions = { // protected because it is needed in other classes and the getters cannot be static
            new DiscreteCoordinates(1,12), new DiscreteCoordinates(1,5)};
    private final static DiscreteCoordinates[] doortoSpawnCoordinates = {
            new DiscreteCoordinates(18,16), new DiscreteCoordinates(18,15)};


    public void createArea() {
        // map
        registerActor(new Background(this));
        registerActor(new Foreground(this));
        // Logics
        Mecanisme fireSidePlate = new PressurePlate(this, new DiscreteCoordinates(5, 10));
        registerActor(fireSidePlate);
        Mecanisme waterSidePlate = new PressurePlate(this, new DiscreteCoordinates(5, 7));
        registerActor(waterSidePlate);
        // doors
        registerActor(new Door("Spawn", Logic.TRUE, doortoSpawnCoordinates, this,
                new DiscreteCoordinates(0, 14), new DiscreteCoordinates(0, 13),
                new DiscreteCoordinates(0, 12), new DiscreteCoordinates(0, 11),
                new DiscreteCoordinates(0, 10)));
        registerActor(new Door("Spawn", Logic.TRUE, doortoSpawnCoordinates, this,
                new DiscreteCoordinates(0, 8), new DiscreteCoordinates(0, 7),
                new DiscreteCoordinates(0, 6), new DiscreteCoordinates(0, 5),
                new DiscreteCoordinates(0, 4)));

        // walls
        for (int i = 0; i < 5; i++) {
            registerActor(new ElementalWall(this, new DiscreteCoordinates(12,10+i), Orientation.LEFT, FIRE,
                    waterSidePlate));
            registerActor(new ElementalWall(this, new DiscreteCoordinates(12,4+i), Orientation.LEFT, WATER,
                    fireSidePlate));
        }
        registerActor(new ElementalWall(this, new DiscreteCoordinates(7,6), Orientation.LEFT, FIRE));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(7, 12), Orientation.LEFT, WATER));

        // items
        registerActor(new Orb(this, new DiscreteCoordinates(17, 12), FIRE));
        registerActor(new Orb(this, new DiscreteCoordinates(17, 6), WATER));
        registerActor(new Heart(this, new DiscreteCoordinates(5, 12))); // fire side
        registerActor(new Heart(this, new DiscreteCoordinates(14, 12)));
        registerActor(new Heart(this, new DiscreteCoordinates(5, 6))); // water side
        registerActor(new Heart(this, new DiscreteCoordinates(14, 6)));

        // set area signal
        setAreaSignal(Logic.TRUE);
    }

    // "ICoopArea" overrides
    @Override
    public DiscreteCoordinates[] getPlayerSpawnPositions() {
        return playersSpawnPositions;
    }
    @Override
    public void setExternalLogic(Logic externalLogic) {}

    // "Playable" overrides
    @Override
    public String getTitle() {
        return "OrbWay";
    }
}
