package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.icoop.actor.items.ElementalItem;
import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.actor.Interactor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.RPGSprite;
import ch.epfl.cs107.play.engine.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

import java.util.ArrayList;
import java.util.List;

public class ElementalWall extends ElementalItem implements Interactor {

    // animation variable
    private Sprite sprite;
    // attack
    private int damage = 1;
    private boolean takeCellSpace;
    private final ElementalWallInteractionHandler elementalWallInteractionHandler = new ElementalWallInteractionHandler();
    private Logic logic;

    public ElementalWall(Area area, DiscreteCoordinates position, Orientation orientation, ElementType type){
        this(area, position, orientation, type, null);
    }

    public ElementalWall(Area area, DiscreteCoordinates position, Orientation orientation, ElementType type, Logic logic) {
        super(area, position, orientation, true, type);
        String spriteName = "_wall";
        switch (type) {
            case FIRE -> spriteName = "fire" + spriteName;
            case WATER -> spriteName = "water" + spriteName;
            default -> throw new IllegalArgumentException("Incorrect type name : " + type);
        }
        Sprite[] wallSprites = RPGSprite.extractSprites(spriteName ,
                4, 1, 1, this , Vector.ZERO , 256, 256);
        sprite = wallSprites[getOrientation().ordinal()];
        this.logic = logic;
    }

    public boolean isOn(){
        if (logic == null) return true;
        else return logic.isOff(); // or ! isON() because active when plate is not walked --> is OFF
    }

    public boolean isOff(){
        return ! isOn();
    }

    public void draw(Canvas canvas) {
        if (isOn()) sprite.draw(canvas);
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }

    public boolean takeCellSpace() {
        return takeCellSpace;
    }

    @Override
    public List<DiscreteCoordinates> getFieldOfViewCells() {
        List<DiscreteCoordinates> coordinates = new ArrayList<>();
        int k = 1;
        for (int i = -k; i <= k; i++) {
            for (int j = -k; j <= k; j++) {
                coordinates.add(getCurrentMainCellCoordinates().jump(i, j));
            }
        }
        return coordinates;
    }

    @Override
    public boolean wantsCellInteraction() {
        return true;
    }

    @Override
    public boolean wantsViewInteraction() {
        return false;
    }

    @Override
    public void interactWith(Interactable other, boolean isCellInteraction) {
        other.acceptInteraction(elementalWallInteractionHandler, isCellInteraction);
    }
    @Override
    public boolean isViewInteractable() {
        return true;
    }

    public void removeFromArea(){
        getOwnerArea().unregisterActor(this);
    }

    private class ElementalWallInteractionHandler implements ICoopInteractionVisitor {

        public void interactWith(ICoopPlayer other, boolean isCellInteraction) {
            if (isOn()){
                if (isCellInteraction){
                    other.takeDamage(damage, getElementType());
                }
            }
            else takeCellSpace = false;
        }
    }
}
