package ch.epfl.cs107.icoop.area;

import ch.epfl.cs107.icoop.actor.decorComponent.Door;
import ch.epfl.cs107.icoop.actor.characters.HellSkull;
import ch.epfl.cs107.play.engine.actor.Background;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.signal.logic.Logic;

public class SanctumEntrance extends ICoopArea{

    protected final static DiscreteCoordinates[] playersSpawnPositions = { // protected because it is needed in other classes and the getters cannot be static
            new DiscreteCoordinates(9, 6), new DiscreteCoordinates(10, 6)};
    public Background background;
    private final int MOVE_DURATION = 10;

    // "ICoopArea" overrides

    @Override
    protected void createArea() {
        // map
        registerActor(new Background(this));
        //registerActor(new Foreground(this));

        // door
        registerActor(new Door("Sanctum", Logic.TRUE, Sanctum.playersSpawnPositions, this, new DiscreteCoordinates(9,14)));
        //registerActor(new SanctumDoor("Sanctum", Sanctum.playersSpawnPositions, this, new DiscreteCoordinates(9,14)));

        // Foe
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(6,12), false));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(7,10), false));
        registerActor(new HellSkull(this, Orientation.LEFT, new DiscreteCoordinates(14,12), false));
        registerActor(new HellSkull(this, Orientation.LEFT, new DiscreteCoordinates(13,10), false));

    }

    @Override
    public void setExternalLogic(Logic externalLogic) {}
    @Override
    public int getMOVE_DURATION(){
        return MOVE_DURATION;
    }
    @Override
    public DiscreteCoordinates[] getPlayerSpawnPositions() {
        return playersSpawnPositions;
    }

    // "Playable" override
    @Override
    public String getTitle() {
        return "SanctumEntrance";
    }


}
