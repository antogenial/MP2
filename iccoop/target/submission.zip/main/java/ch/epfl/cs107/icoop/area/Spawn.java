package ch.epfl.cs107.icoop.area;

import ch.epfl.cs107.icoop.actor.*;
import ch.epfl.cs107.icoop.actor.decorComponent.DialogDoor;
import ch.epfl.cs107.icoop.actor.decorComponent.Door;
import ch.epfl.cs107.icoop.actor.decorComponent.Obstacle;
import ch.epfl.cs107.icoop.actor.decorComponent.Rock;
import ch.epfl.cs107.icoop.handler.DialogHandler;
import ch.epfl.cs107.play.engine.actor.Background;
import ch.epfl.cs107.play.engine.actor.Dialog;
import ch.epfl.cs107.play.engine.actor.Foreground;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;

public class Spawn extends ICoopArea implements DialogOwner{
    private DialogHandler dialogHandler;
    private boolean isVisible;
    private Logic externalLogic;
    private DialogDoor finalDoor;
    private Dialog dialog;

    protected final static DiscreteCoordinates[] playersSpawnPositions = { // protected because it is needed in other classes and the getters cannot be static
            new DiscreteCoordinates(14, 6), new DiscreteCoordinates(13, 6)};

    public Spawn(DialogHandler dialogHandler) {
        this.dialogHandler = dialogHandler;
        isVisible = false;
    }

    // "ICoopArea" overrides

    @Override
    public void createArea() {
        // maps
        registerActor(new Background(this));
        registerActor(new Foreground(this));
        // doors
        registerActor(new Door("OrbWay", Logic.TRUE, OrbWay.playersSpawnPositions, this, new DiscreteCoordinates(19,15), new DiscreteCoordinates(19,16)));
        registerActor(new Door("Maze", Logic.TRUE, Maze.playersSpawnPositions, this, new DiscreteCoordinates(4,0), new DiscreteCoordinates(5,0)));
        //finalDoor = new DialogDoor("SanctumEntrance", Logic.FALSE, SanctumEntrance.playersSpawnPositions, this, new DiscreteCoordinates(6, 11), "victory", "key_required");
        // to test extensions without completing whole game
        finalDoor = new DialogDoor("SanctumEntrance", Logic.TRUE, SanctumEntrance.playersSpawnPositions, this, new DiscreteCoordinates(6, 11), "victory", "key_required");
        registerActor(finalDoor);

        // items
        registerActor(new Obstacle(this, new DiscreteCoordinates(10, 10)));
        registerActor(new Explosif(this, new DiscreteCoordinates(11, 10)));
        registerActor(new Rock(this, new DiscreteCoordinates(11, 11)));


        // set area signal
        setAreaSignal(Logic.TRUE);
    }

    @Override
    public void update(float deltaTime) {
        if (!isVisible) {
            dialog = new Dialog("welcome");
            dialogHandler.publish(dialog);
            isVisible = true;
        }
        super.update(deltaTime);
        if (externalLogic != null){
            finalDoor.setSignal(externalLogic);
            externalLogic = null;
        }
    }

    // ICoopArea
    @Override
    public DiscreteCoordinates[] getPlayerSpawnPositions() {
        return playersSpawnPositions;
    }
    @Override

    public void setExternalLogic(Logic externalLogic) {
        this.externalLogic = externalLogic;
    }

    // "Playable" overrides
    @Override
    public String getTitle() {
        return "Spawn";
    }

    // Dialog Owner
    @Override
    public Dialog getDialog() {
        return dialog;
    }
}
