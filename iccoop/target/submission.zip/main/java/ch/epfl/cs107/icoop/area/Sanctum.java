package ch.epfl.cs107.icoop.area;

import ch.epfl.cs107.icoop.ICoopBehaviour;
import ch.epfl.cs107.icoop.actor.decorComponent.*;
import ch.epfl.cs107.icoop.actor.items.Coin;
import ch.epfl.cs107.icoop.actor.items.Diamond;
import ch.epfl.cs107.play.engine.actor.Background;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.signal.logic.And;
import ch.epfl.cs107.play.signal.logic.Logic;

public class Sanctum extends ICoopArea{

    protected final static DiscreteCoordinates[] playersSpawnPositions = { // protected because it is needed in other classes and the getters cannot be static
            new DiscreteCoordinates(7, 0), new DiscreteCoordinates(8, 0)};
    public Background background;
    private final int MOVE_DURATION = 14;

    // "ICoopArea" overrides

    @Override
    protected void createArea() {
        // decor
        registerActor(new Background(this));
        //registerActor(new Foreground(this));

        // logic
        Mecanisme pressurePlate1 = new PressurePlate(this, new DiscreteCoordinates(3, 12));
        registerActor(pressurePlate1);
        Mecanisme pressurePlate2 = new PressurePlate(this, new DiscreteCoordinates(12, 12));
        registerActor(pressurePlate2);
        Logic doublePlateMecanimse = new And(pressurePlate1, pressurePlate2);

        // element behaviour
        registerActor(new Throne(this, Orientation.DOWN, new DiscreteCoordinates(7,12)));
        registerActor(new Throne(this, Orientation.DOWN, new DiscreteCoordinates(8,12)));

        Chest silverChest = new Chest(this, new DiscreteCoordinates(4, 12),  "icoop/silver_chest",  15);
        registerActor(silverChest);
        Chest goldChest = new Chest(this, new DiscreteCoordinates(5, 12),  "icoop/gold_chest",18);
        registerActor(goldChest);
        Chest diamondChest = new Chest(this, new DiscreteCoordinates(11,12),  "icoop/diamond_chest", 16);
        registerActor(diamondChest);
        registerActor(new Cage(this, new DiscreteCoordinates(10, 12), doublePlateMecanimse));

        // items part 1 : choose the position by type ( silver / gold coins, diamonds)
        int goldCounter = 0, silverCounter = 0, diamondCounter = 0;
        int[] colone = {3, 4, 5, 10, 11,12};
        int c =0, z, j = 0;
        for (int y = 3; y < 12; ++y) {
            for (int x : colone) {
                if (getCellType(new DiscreteCoordinates(x, y)) == ICoopBehaviour.CellType.WALKABLE) {
                    //if ((x % 2 == 0 && y % 2 != 0) || (x % 2 != 0 && y %2 == 0)) {}
                    ++c;
                    if (c > 3) {
                        c = 0;
                    }
                    z = y + c;
                    if (z % 3 == 0) {
                        registerActor(new Coin(this, new DiscreteCoordinates(x, y), Coin.Material.SILVER, silverChest));
                        ++silverCounter;
                    } else if ((z % 3 == 1)) {
                        registerActor(new Coin(this, new DiscreteCoordinates(x, y), Coin.Material.GOLD, goldChest));
                        ++goldCounter;
                    } else {//diamond
                        registerActor(new Diamond(this, new DiscreteCoordinates(x, y), diamondChest));
                        ++diamondCounter;
                    }
                }
            }
        }
        silverChest.setFullThreshold(silverCounter);
        goldChest.setFullThreshold(goldCounter);
        diamondChest.setFullThreshold(diamondCounter);

        // door
        registerActor(new Teleporter("Spawn", Logic.TRUE, Spawn.playersSpawnPositions, this, new DiscreteCoordinates(10,11)));
    }
    @Override
    public DiscreteCoordinates[] getPlayerSpawnPositions() {
        return playersSpawnPositions;
    }
    @Override
    public void setExternalLogic(Logic externalLogic) {}

    // "Playable" overrides

    @Override
    public String getTitle() {
        return "Sanctum";
    }
}
