package ch.epfl.cs107.icoop.actor.items;

import ch.epfl.cs107.icoop.actor.decorComponent.Chest;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.CollectableAreaEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;

import java.util.Collections;
import java.util.List;

public abstract class ICoopCollectable extends CollectableAreaEntity {

    private final Chest CORESPONDING_CHEST; // to update the sprite depending on the amount of coins
    private boolean canBeDestroy;

    public ICoopCollectable(Area area, Orientation orientation, DiscreteCoordinates position, boolean canBeDestroy) {
        this(area, orientation, position, canBeDestroy, null); // chest optional
    }

    public ICoopCollectable(Area area, Orientation orientation, DiscreteCoordinates position, boolean canBeDestroy, Chest corespondingChest) {
        super(area, orientation, position);
        CORESPONDING_CHEST = corespondingChest;
        this.canBeDestroy = canBeDestroy;
    }

    @Override
    public void collect() {
        super.collect();
        removeFromArea();
        if (CORESPONDING_CHEST != null){
            CORESPONDING_CHEST.addElement(); // increment chest's coin amount
        }
    }

    private void removeFromArea(){
        getOwnerArea().unregisterActor(this);
    }

    public void destroy(){
        if (canBeDestroy){
            removeFromArea();
        }
    }

    // "Interactor" override

    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }

    // "Interactable" overrides

    @Override
    public boolean takeCellSpace() {
        return false;
    }

    @Override
    public boolean isCellInteractable() {
        return true;
    }

    @Override
    public boolean isViewInteractable() {
        return true;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }
}
