package ch.epfl.cs107.icoop.actor.items;

import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.window.Canvas;

public class Heart extends ICoopCollectable {

    // health
    private int hp;
    // animation
    private final static int ANIMATION_DURATION = 24;
    private Animation sprite;
    private final static int CASE_SIZE = 16;

    public Heart(Area area, DiscreteCoordinates position) {
        this(area, position, 1);
    }

    public Heart(Area area, DiscreteCoordinates position, int hp) {
        super(area, Orientation.UP, position, false);
        // assignment
        this.hp = hp;
        // animation
        sprite = new Animation("icoop/heart", 4, 1, 1, this, CASE_SIZE, CASE_SIZE, ANIMATION_DURATION / 4, true);
    }

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        sprite.update(deltaTime);
    }

    public int getHp() {
        return hp;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }
}

