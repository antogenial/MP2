package ch.epfl.cs107.icoop.actor;

public interface Unstoppable {
    default boolean unstoppable(){
       return true;
   }

    /*default boolean canFlyOver(){
        return  false;
    }*/
}
