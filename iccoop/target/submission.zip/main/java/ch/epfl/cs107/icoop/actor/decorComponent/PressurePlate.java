package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.RPGSprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.window.Canvas;


public class PressurePlate extends Mecanisme {

    // animation variables
    private RPGSprite sprite;

    public PressurePlate(Area area, DiscreteCoordinates position){
        super(area, Orientation.DOWN, position, true,"GroundLightOn", "GroundLightOff");
        // animation init
        RegionOfInterest roi = new RegionOfInterest(0, 0, CASE_SIZE, CASE_SIZE);
        sprite =  new RPGSprite("GroundPlateOff", 1, 1, this, roi);
    }
    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
    }

    public void draw(Canvas canvas) {
        sprite.draw(canvas); // draw main sprite (plate)
        super.draw(canvas); // draw corresponding light
    }
}