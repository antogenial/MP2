package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.play.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.RPGSprite;
import ch.epfl.cs107.play.engine.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.window.Canvas;

import java.util.Collections;
import java.util.List;

public class Mecanisme extends AreaEntity implements Logic {


    // logic variables
    private boolean active = false;
    private boolean resumeState; // true for auto resume / false for stay until next interaction
    private boolean readyForSwitch = false; // (only if resumeState) delay the return to the idle state by one frame, to remain active if the interaction continues
    // animation variables
    public final static int CASE_SIZE = 16; // child need to have it, and it's final --> no encapsulation problem
    private Sprite[] sprites = new RPGSprite[2];
    private Sprite sprite;

    public Mecanisme(Area area, Orientation orientation,DiscreteCoordinates position, boolean resumeState ,String imageNamesOn, String imageNamesOff){
        super(area, orientation, position);
        // set attributes
        this.resumeState = resumeState;
        // animation
        String[] imageNames = {imageNamesOff, imageNamesOn};
        RegionOfInterest roi = new RegionOfInterest(0, 0, CASE_SIZE, CASE_SIZE);
        for (int i = 0; i <imageNames.length ; i++) {
            sprites[i] =  new RPGSprite(imageNames[i], 1, 1, this, roi);
        }
        updateSprite(); // set default sprite
    }

    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        updateSprite();
        if (readyForSwitch) active = false; // switch to default state
        if (resumeState) readyForSwitch = true; // leave state switching (on next frame)

    }

    private void updateSprite(){
        sprite = sprites[(active)?1:0];  // (walkOn)?1:0 set index : = if false and 1 if true
    }

    public void use(boolean use){ // set state
        this.active = use;
        readyForSwitch = false; // postpones state's switch back
    }

    @Override
    public boolean isOn() {
        return active;
    }

    @Override
    public boolean isOff() {
        return !active;
    }

    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }

    @Override
    public boolean takeCellSpace() {
        return false;
    }

    @Override
    public boolean isCellInteractable() {
        return true;
    }

    @Override
    public boolean isViewInteractable() {
        return false;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }
}

