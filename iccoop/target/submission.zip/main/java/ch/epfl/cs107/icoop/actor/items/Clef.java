package ch.epfl.cs107.icoop.actor.items;

import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.icoop.handler.ICoopInventoryItem;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.icoop.handler.ICoopItem;

public class Clef extends ElementalItem implements ICoopInventoryItem {

    private final Sprite SPRITE;
    private ICoopItem itemType;

    public Clef(Area area, DiscreteCoordinates position, ElementType elementType) {
        super(area, position, Orientation.LEFT, false,  elementType);
        // animation
        SPRITE = new Sprite("icoop/key_"+elementType.COLOR, 0.6f, 0.6f, this);
        // type assignment: assign the corresponding inventory type
        switch (elementType) {
            case ElementType.FIRE:
                itemType = ICoopItem.FIREKEY;
                break;

            case ElementType.WATER:
                itemType = ICoopItem.WATERKEY;
                break;
        }
    }

    public ICoopItem getItemType(){
        return itemType;
    }

    // Actor overrides

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
    }
    @Override
    public void draw(Canvas canvas) {
        SPRITE.draw(canvas);
    }

    // Interactable overrides

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }

    // Inventory overrides
    @Override
    public int getPocketId() {
        return 0;
    }
    @Override
    public String getName() {
        return "Key";
    }
}
