package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.RPGSprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

import java.util.Collections;
import java.util.List;

public class Cage extends AreaEntity {

    // animation variables
    private final static int IMAGE_SIZE = 16;
    private static RPGSprite[] sprites = new RPGSprite[2];
    private RPGSprite sprite;
    // logics variables
    private boolean keepOpen = true;
    private Logic signal;

    public Cage(Area area, DiscreteCoordinates position, Logic signal) {
        super(area, Orientation.UP, position);
        // set attributes
        this.signal = signal;
        // animation
        RegionOfInterest roi;
        for (int i = 0; i < sprites.length; i++) {
            roi = new RegionOfInterest(i * IMAGE_SIZE, 0, IMAGE_SIZE, 2*IMAGE_SIZE);
            sprites[i] = new RPGSprite("icoop/cage", 1, 2, this , roi);
        }
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        int index;
        if (keepOpen){
            index = 1;
        }
        else {
            index = (int) signal.getIntensity(); // getIntensity = 0 is isOFF and 1 if isOn
        }
        sprite = sprites[index];
    }

    public void setKeepOpen(boolean keepOpen) {
        this.keepOpen = keepOpen;
    }

    public boolean isOpen(){
        return keepOpen || signal.isOn();
    }

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    // AreaEntity
    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }

    @Override
    public boolean takeCellSpace() {
        return false;
    }

    @Override
    public boolean isCellInteractable() {
        return true;
    }

    @Override
    public boolean isViewInteractable() {
        return false;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }
}
