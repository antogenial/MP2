package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.engine.actor.RPGSprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Teleporter extends Door {

    // animation
    private RPGSprite sprite;

    public Teleporter(String destination, Logic signal, DiscreteCoordinates[] spawnCoordinates, Area area, DiscreteCoordinates position) {
        super(destination, signal, spawnCoordinates, area, position);
        // animation
        RegionOfInterest roi = new RegionOfInterest(0, 0, 32, 32);
        sprite = new RPGSprite("shadow", 1, 1, this , roi);
    }

    public boolean active(){
        return getSignal().isOn();
    }

    @Override
    public void draw(Canvas canvas) {
        if (active()) sprite.draw(canvas);
    }
}
