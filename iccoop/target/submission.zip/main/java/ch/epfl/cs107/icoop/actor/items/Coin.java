package ch.epfl.cs107.icoop.actor.items;

import ch.epfl.cs107.icoop.actor.decorComponent.Chest;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.window.Canvas;

public class Coin extends ICoopCollectable {

    // animation variables
    private Animation sprite;
    private final static int ANIMATION_DURATION = 18;
    private Material material;

    public Coin(Area area, DiscreteCoordinates position, Material material) {
        this(area, position, material, null);
    }

    public Coin(Area area, DiscreteCoordinates position, Material material, Chest corespondingChest) {
        super(area, Orientation.UP, position, true, corespondingChest);
        // attribute allocation
        this.material = material;
        // animation init
        sprite = new Animation(material.spriteName, 4, 1, 1, this, 16, 16,
                ANIMATION_DURATION / 4, true);

    }
    public static enum Material{ //coin type
        GOLD("icoop/coin"),
        SILVER("icoop/coin_silver");
        public final String spriteName;
        Material(String spriteName){
            this.spriteName = spriteName;
        }
    }

    // Actor overrides
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        sprite.update(deltaTime);
    }
    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }


    // Interactable

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }
}
