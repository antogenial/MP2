package ch.epfl.cs107.icoop.handler;

import ch.epfl.cs107.icoop.ICoopBehaviour;
import ch.epfl.cs107.icoop.actor.*;
import ch.epfl.cs107.icoop.actor.characters.BombFoe;
import ch.epfl.cs107.icoop.actor.characters.Foe;
import ch.epfl.cs107.icoop.actor.characters.HellSkull;
import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;
import ch.epfl.cs107.icoop.actor.decorComponent.*;
import ch.epfl.cs107.icoop.actor.items.*;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.areagame.handler.InventoryItem;
import ch.epfl.cs107.play.engine.actor.Actor;

/**
 * InteractionVisitor for the ICoop entities
 */

public interface ICoopInteractionVisitor extends AreaInteractionVisitor {
    /// Add Interaction method with all non Abstract Interactable

    default void interactWith(ICoopBehaviour.ICoopCell other, boolean isCellInteraction) {}

    default void interactWith(ICoopPlayer other, boolean isCellInteraction) {}

    default void interactWith(Door other, boolean isCellInteraction) {}

    default void interactWith(DialogDoor other, boolean isCellInteraction) {}

    default void interactWith(Obstacle other, boolean isCellInteraction) {}

    default void interactWith(Rock other, boolean isCellInteraction) {}

    default void interactWith(Explosif other, boolean isCellInteraction) {}

    default void interactWith (ElementalWall other, boolean isCellInteraction) {}

    default void interactWith (Throne other, boolean isCellInteraction) {}

    default void interactWith (Chest other, boolean isCellInteraction) {}

    default void interactWith (Cage other, boolean isCellInteraction) {}

    default void interactWith (ICoopInventoryItem other, boolean isCellInteraction) {}

    default void interactWith (DialogOwner other, boolean isCellInteraction) {}

    // Foe
    default void interactWith (Foe other, boolean isCellInteraction) {}
    default void interactWith (HellSkull other, boolean isCellInteraction) {
        interactWith((Foe)other, isCellInteraction);
    }
    default void interactWith (BombFoe other, boolean isCellInteraction) {
        interactWith((Foe)other, isCellInteraction);
    }

    // Collectable
    default void interactWith (ICoopCollectable other, boolean isCellInteraction) {}
    default void interactWith (Heart other, boolean isCellInteraction) {
        interactWith((ICoopCollectable)other, isCellInteraction);
    }
    default void interactWith (Coin other, boolean isCellInteraction) {
        interactWith((ICoopCollectable)other, isCellInteraction);
    }
    default void interactWith (Diamond other, boolean isCellInteraction) {
        interactWith((ICoopCollectable)other, isCellInteraction);
    }

    // ElementalItem
    default void interactWith (ElementalItem other, boolean isCellInteraction) {
        interactWith((ICoopCollectable)other, isCellInteraction);
    }
    default void interactWith (Staff other, boolean isCellInteraction) {
        interactWith((ElementalItem) other, isCellInteraction);
        interactWith((ICoopInventoryItem) other, isCellInteraction);
    }
    default void interactWith (Clef other, boolean isCellInteraction) {
        interactWith((ElementalItem) other, isCellInteraction);
        interactWith((ICoopInventoryItem) other, isCellInteraction);
    }
    default void interactWith (Orb other, boolean isCellInteraction) {
        interactWith((ElementalItem) other, isCellInteraction);
        interactWith((DialogOwner) other, isCellInteraction);
    }

    // Mecanismes
    default void interactWith (Mecanisme other, boolean isCellInteraction){}
    default void interactWith (PressurePlate other, boolean isCellInteraction) {
        interactWith((Mecanisme) other, isCellInteraction);
    }
    default void interactWith (Levier other, boolean isCellInteraction) {
        interactWith((Mecanisme) other, isCellInteraction);
    }
}
