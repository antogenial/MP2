package ch.epfl.cs107.icoop.actor.items;

import ch.epfl.cs107.icoop.actor.ElementEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.signal.logic.Logic;

public abstract class ElementalItem extends ICoopCollectable implements Logic, ElementEntity {

    private ElementType elementType;

    public ElementalItem(Area area, DiscreteCoordinates position, Orientation orientation, boolean canBeDestroy,  ElementType elementType) {
        super(area, orientation, position, canBeDestroy);
        this.elementType = elementType;
    }

    public void collect(ElementType collectorType) {
        if (elementType == collectorType){
            super.collect();
        }
    }

    // ElementType overrides
    @Override
    public ElementType getElementType() {
        return elementType;
    }

    @Override
    public boolean isOn() {
        return isCollected();
    }

    @Override
    public boolean isOff() {
        return ! isCollected();
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
    }
}
