package ch.epfl.cs107.icoop.actor.projectiles;

import ch.epfl.cs107.icoop.actor.ElementEntity;
import ch.epfl.cs107.icoop.actor.Explosif;
import ch.epfl.cs107.icoop.actor.characters.Foe;
import ch.epfl.cs107.icoop.actor.decorComponent.Obstacle;
import ch.epfl.cs107.icoop.actor.decorComponent.Rock;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.window.Canvas;

public class Ball extends Projectile implements ElementEntity {

    private final static int DAMAGE = 1;
    private final static int ANIMATION_DURATION = 12;
    private final static int DISTANCE_MAX = 10;
    private final static int SPEED = 3;
    private final BallInteractionHandler ballInteractionHandler = new BallInteractionHandler();
    private final ElementEntity.ElementType elementType;
    private Animation sprite;

    public Ball(Area owner, Orientation orientation, DiscreteCoordinates coordinates, ElementEntity.ElementType elementType) {
        super(owner, orientation, coordinates, SPEED, DISTANCE_MAX);
        this.elementType = elementType;
        sprite = new Animation("icoop/magic"+this.elementType.toString()+"Projectile",  4, 1, 1,
                this , 32, 32, ANIMATION_DURATION/4, true);

    }

    // Actor overrides

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        sprite.update(deltaTime);
    }

    // ElementEntity override

    @Override
    public ElementEntity.ElementType getElementType() {
        return elementType;
    }

    // Projectiles override

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    // Interactable override

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }

    // Interactor overrides

    @Override
    public void interactWith(Interactable other, boolean isCellInteraction) {
        other.acceptInteraction(ballInteractionHandler, isCellInteraction);
    }


    private class BallInteractionHandler implements ICoopInteractionVisitor {

        public void interactWith(Foe other, boolean isCellInteraction) {
            if (isCellInteraction) {
                other.takeDamage(DAMAGE, elementType);
                collision();
            }
        }

        public void interactWith(Explosif other, boolean isCellInteraction) {
            if (isCellInteraction){
                other.activate();
                collision();
            }
        }
        public void interactWith(Rock other, boolean isCellInteraction) {
            if (isCellInteraction){
                other.removeFromArea();
                collision();
            }
        }

        public void interactWith(Obstacle other, boolean isCellInteraction) {
            if (isCellInteraction) {
                collision();
            }
        }
    }
}
