package ch.epfl.cs107.icoop.actor.characters;

import ch.epfl.cs107.icoop.KeyBindings;
import ch.epfl.cs107.icoop.Timer;
import ch.epfl.cs107.icoop.actor.DialogOwner;
import ch.epfl.cs107.icoop.actor.ElementEntity;
import ch.epfl.cs107.icoop.actor.Explosif;
import ch.epfl.cs107.icoop.actor.Health;
import ch.epfl.cs107.icoop.actor.decorComponent.*;
import ch.epfl.cs107.icoop.actor.items.*;
import ch.epfl.cs107.icoop.actor.projectiles.Ball;
import ch.epfl.cs107.icoop.area.ICoopArea;
import ch.epfl.cs107.icoop.handler.*;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.actor.Interactor;
import ch.epfl.cs107.play.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.areagame.handler.InventoryItem;
import ch.epfl.cs107.play.engine.actor.Dialog;
import ch.epfl.cs107.play.engine.actor.OrientedAnimation;
import ch.epfl.cs107.play.math.*;
import ch.epfl.cs107.play.window.Button;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Canvas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static ch.epfl.cs107.icoop.KeyBindings.BLUE_PLAYER_KEY_BINDINGS;
import static ch.epfl.cs107.icoop.KeyBindings.RED_PLAYER_KEY_BINDINGS;
import static ch.epfl.cs107.play.math.Orientation.*;

/**
 * A ICoopPlayer is a player for the ICoop game.
 */
public class ICoopPlayer extends MovableAreaEntity implements Interactor, ElementEntity, ICoopInventory.Holder {

    // health
    private static int MAX_LIFE = 5;
    private Health healthBar;
    private final static float IMMUNITY_PERIOD = 2;
    private Timer immunityTimer = new Timer(IMMUNITY_PERIOD);
    private boolean isUnvulnerable = false;
    private ElementEntity.ElementType elementImunity = null;
    // animations
    private static int MOVE_DURATION;
    final Orientation[] orders = {DOWN, RIGHT, UP, LEFT};
    private final static int SWORD_ANIMATION_DURATION = 2, STAFF_ANIMATION_DURATION = 2;
    final Vector healthBarAnchor = new Vector(0, 0),
            swordAnchor = new Vector(-.5f, 0),
            staffAnchor = new Vector(-.5f,-.20f);
    private OrientedAnimation sprite;
    private OrientedAnimation[] sprites = new OrientedAnimation[3];
    // attack attributes
    private Timer staffBallTimer = new Timer(Staff.SHOOT_FREQUENCY);
    private static int damage = 2;
    // inventory attributes
    private ICoopInventory inventory = new ICoopInventory("ICoopInventory") {};
    private List <ICoopItem> items = new ArrayList<ICoopItem>();
    private ICoopItem currentItem;
    private int itemIndex = 0;  // index to cycle through the list of items
    private ICoopPlayerStatusGUI playerStatusGUI;
    // player state attributes
    private boolean isAttacking = false;
    private boolean isOnItem;
    private boolean animationMode = false;
    private boolean isSeated = false;
    private boolean isInCage = false;
    private boolean wantsInteraction = false;
    // transmission variables
    private Door door = null;
    private Dialog dialog = null;
    // activity variables
    private KeyBindings.PlayerKeyBindings keys;
    private ICoopPlayerInteractionHandler iCoopPlayerInteractionHandler = new ICoopPlayerInteractionHandler();
    // other
    private final ElementType elementType;

    public ICoopPlayer(Area owner, Orientation orientation, DiscreteCoordinates coordinates, ElementType elementType) {
        super(owner, orientation, coordinates);

        this.elementType = elementType;

        inventory.addPocketItem(ICoopItem.SWORD,1);
        inventory.addPocketItem(ICoopItem.EXPLOSIVE,2);

        items.add(ICoopItem.SWORD);
        items.add(ICoopItem.EXPLOSIVE);
        currentItem = items.getFirst();

        staffBallTimer.setNull();
        updateMoveDuration();

        // element type particularities
        String fileRoot, fileName;
        boolean fliped;
        switch (elementType) {
            case ElementType.FIRE:
                fileRoot = "icoop/player";
                keys = RED_PLAYER_KEY_BINDINGS;
                fliped = true;

                break;
            case ElementType.WATER:
                fileRoot = "icoop/player2";
                keys = BLUE_PLAYER_KEY_BINDINGS;
                fliped = false;
                break;
            default:
                throw new IllegalArgumentException("Incorrect elemantlType : " + elementType);
        }

        // animations
        playerStatusGUI = new ICoopPlayerStatusGUI(this, fliped);
        healthBar = new Health(this, Transform.I.translated(0, 1.75f), MAX_LIFE, true);
        sprites[0] = new OrientedAnimation(fileRoot, MOVE_DURATION, this, healthBarAnchor, orders, 4, 1, 2, 16, 32, true);
        fileName = fileRoot + ".sword";
        sprites[1] = new OrientedAnimation(fileName, SWORD_ANIMATION_DURATION, this, swordAnchor, orders, 4, 2, 2, 32, 32);
        fileName = fileRoot + ".staff_" + elementType.toString().toLowerCase();
        sprites[2] =  new OrientedAnimation(fileName , STAFF_ANIMATION_DURATION, this, staffAnchor, orders, 4, 2, 2, 32, 32);
        choseSprite();
    }


    // Getters

    public Door getDoor() {
        return door;
    }

    public Dialog getDialog() {
        return dialog;
    }

    public ElementType getElementType() {
        return elementType;
    }

    public ICoopItem getCurrentItem() {
        return currentItem;
    }

    // Setters

    public void setDoor(Door door) {
        this.door = door;
    }


    // Actor overrides

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        // keyboard management
        Keyboard keyboard = getOwnerArea().getKeyboard();

        // movement
        updateMoveDuration();
        if (getOwnerArea().getTitle().equals("SanctumEntrance")) { // this area is dictated by update ("animation mode")
            animationMode = true;
            moveOriented(Orientation.UP);
        } else {
            animationMode = false;
        }
        if (!isSeated) {    // move in corresponding direction
            /*moveIfPressed(Orientation.UP, keyboard.get(keys.up()));
            moveIfPressed(Orientation.DOWN, keyboard.get(keys.down()));
            moveIfPressed(Orientation.RIGHT, keyboard.get(keys.right()));
            moveIfPressed(Orientation.LEFT, keyboard.get(keys.left()));*/
            moveOriented(getOrientationByKey(keyboard));
        }

        // inventory
        if (keyboard.get(keys.switchItem()).isPressed()) {
            switchItem();
        }
        if (wantsInteraction) {
            useEquipment(currentItem);
        }
        while (!inventory.contains(currentItem)){
            switchItem();
        }


        staffBallTimer.update(deltaTime); // update staffBallTimer who control the staff's shooting frequency

        // animation
        choseSprite();
        if (isDisplacementOccurs() || isAttacking) { // update sprite if player in idle
            sprite.update(deltaTime);
        } else {
            sprite.reset();
        }

        // interaction
        if (!animationMode) {
            wantsInteraction = (keyboard.get(keys.useItem()).isPressed()); // true if action key is pressed
        }
        isOnItem = false;

        // health
        if (isUnvulnerable) { // if isUnvulnerable, a starter strat
            immunityTimer.update(deltaTime);
            if(immunityTimer.isOver()){
                isUnvulnerable = false;
                immunityTimer.reset();
            }
        }

        // dialog
        if (dialog != null && dialog.isCompleted()) dialog = null;
    }

    @Override
    public void draw(Canvas canvas) {
        if (!isUnvulnerable || ((int)(immunityTimer.getTimeLeft()*28)) % 2 == 0) {      // toggles player flashing effect
            sprite.draw(canvas);
        }
        if (!animationMode) {
            healthBar.draw(canvas);
            playerStatusGUI.draw(canvas);
        }
    }

    private Orientation getOrientationByKey(Keyboard keyboard){
        if (keyboard.get(keys.up()).isDown()){
            return UP;
        } else if (keyboard.get(keys.down()).isDown()) {
            return DOWN;
        }
        else if (keyboard.get(keys.right()).isDown()) {
            return RIGHT;
        }
        else if (keyboard.get(keys.left()).isDown()) {
            return LEFT;
        }
        return null;
    }
    // Private methods

    // When called, depending on which item is set as the current item, the associated action is done
    private void useEquipment(ICoopItem currentItem) {

        switch (currentItem) {
            case ICoopItem.EXPLOSIVE:   // registers an actor "bomb" in front of player
                if (inventory.contains(ICoopItem.EXPLOSIVE)) {
                    DiscreteCoordinates CoordInFrontOfPlayer = getFieldOfViewCells().getFirst(); // get cell front of player
                    if (((ICoopArea)getOwnerArea()).isCellEmpty(CoordInFrontOfPlayer) || ((ICoopArea)getOwnerArea()).doesCellContain(CoordInFrontOfPlayer, PressurePlate.class)) { // et cellule courante pas interactable expetion pour les pressurePlate
                        Area currentArea = getOwnerArea();
                        currentArea.registerActor(new Explosif(currentArea, CoordInFrontOfPlayer)); // registration
                        inventory.removePocketItem(ICoopItem.EXPLOSIVE, 1);
                    }
                    break;
                }
            case ICoopItem.SWORD:   // sets "isAttacking" boolean to true
                if (inventory.contains(ICoopItem.SWORD) && !isAttacking) {
                    isAttacking = true;
                    break;
                }
            case ICoopItem.FIRESTAFF:  // sets "isAttacking" boolean to true and shoots a ball
                if (inventory.contains(ICoopItem.FIRESTAFF) && !isAttacking) {
                    isAttacking = true;
                    shootElementBall(ElementType.FIRE);
                    break;
                }

            case ICoopItem.WATERSTAFF:   // sets "isAttacking" boolean to true and shoots a ball
                if (inventory.contains(ICoopItem.WATERSTAFF) && !isAttacking) {
                    isAttacking = true;
                    shootElementBall(ElementType.WATER);
                    break;
                }
        }
    }

    private void updateMoveDuration() {
        MOVE_DURATION = ((ICoopArea)getOwnerArea()).getMOVE_DURATION(); // every Area have his own move duration
    }

    //private void moveIfPressed(Orientation orientation, Button b) { // move in the wanted direction if pressed
        //if (b.isDown()) {
        //    moveOriented(orientation);
        //}
    //}

    private void moveOriented(Orientation orientation) { // moves in the desired orientation
        if (!isDisplacementOccurs() && orientation != null) {
            orientate(orientation);
            if (!isInCage){
                move(MOVE_DURATION);
            }
        }

    }

    private void switchItem() {
        ++itemIndex;
        if (itemIndex >= items.size()) {
            itemIndex = 0;
        }
        currentItem = items.get(itemIndex);
    }

    private void shootElementBall(ElementType staffType) {
        if (staffBallTimer.isOver()){ // if waiting time is over a new shoot is possible
            getOwnerArea().registerActor(new Ball(getOwnerArea(), getOrientation(), getFieldOfViewCells().getFirst(), staffType));
            staffBallTimer.reset();
        }
    }

    private boolean canHit(){   // Returns whether the player is able to hit depending on his current state
        return wantsInteraction && currentItem == ICoopItem.SWORD;
    }

    private void choseSprite() {    // Assigns the corresponding sprite depending on the player's current state

        int defaultIndex = 0;
        int newSpriteIndex; // index of the neeeded sprite
        if (isAttacking) {
            newSpriteIndex = switch (currentItem) {
                case ICoopItem.SWORD -> 1;
                case ICoopItem.FIRESTAFF, ICoopItem.WATERSTAFF -> 2;
                default -> defaultIndex;
            };
        }
        else {
            newSpriteIndex = defaultIndex;
        }
        sprite = sprites[newSpriteIndex];
        if (sprite.isCompleted() && sprite != sprites[defaultIndex]) { // reset if action (!= walking) is over
            sprite = sprites[defaultIndex];
            sprite.reset();
            isAttacking = false;
        }
        // resets not current sprite
        for (int i = 0; i < sprites.length; ++i) {
            if (i != newSpriteIndex) {
                sprites[i].reset();
            }
        }
    }

    // Public methods

    public void enterArea (Area area, DiscreteCoordinates position) {
        area.registerActor(this);
        area.setViewCandidate(this);
        setOwnerArea(area);
        setCurrentPosition(position.toVector());
        resetMotion();
    }

    public void leaveArea() {
        getOwnerArea().unregisterActor(this);
    }

    public void takeDamage(int damage) {
        if (!isUnvulnerable) {
            healthBar.decrease(damage);
            isUnvulnerable = true;
        }
    }

    public void takeDamage(int damage, ElementType type) {
        if (elementImunity == null || type != elementImunity) { // take damage from an elemental typed source
            takeDamage(damage);
        }
    }

    public void addHealth(int hp){
        healthBar.increase(hp);
    }

    public void addHealth(int hp, ElementType type) { // add health from an elemental typed source
        if (type == this.elementType){
            addHealth(hp);
        }
    }

    public boolean isDead() {
        return healthBar.isOff();
    }

    // ICoopInventory.Holder override
    @Override
    public boolean possess(InventoryItem item) {
        return inventory.contains(item);

    }

    // Interactable overrides

    @Override
    public boolean takeCellSpace() {
        return true;
    }

    @Override
    public boolean isCellInteractable() {
        return true;
    }

    @Override
    public boolean isViewInteractable() {
        return true;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor) v).interactWith(this, isCellInteraction);
    }


    // Interactor

    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates()); // Return only the main cell
    }

    @Override
    public List<DiscreteCoordinates> getFieldOfViewCells() { // Determines the range for a potential distance interaction with an interactor
        return Collections.singletonList(getCurrentMainCellCoordinates().jump(getOrientation().toVector()));
    }

    @Override
    public boolean wantsCellInteraction() {
        return true;
    }

    @Override
    public boolean wantsViewInteraction() {
        return wantsInteraction;
    }

    @Override
    public void interactWith(Interactable other, boolean isCellInteraction) {
        other.acceptInteraction(iCoopPlayerInteractionHandler, isCellInteraction);
    }



    private class ICoopPlayerInteractionHandler implements ICoopInteractionVisitor {
        // generals
        public void interactWith (ICoopCollectable other, boolean isCellInteraction) {
            if (isCellInteraction) {
                other.collect();
            }
        }

        public void interactWith (ICoopInventoryItem other, boolean isCellInteraction) {
            if (isCellInteraction && (other instanceof ElementalItem || elementType == ((ElementalItem)other).getElementType())) {
                inventory.addPocketItem(other.getItemType(), 1);
                items.add(other.getItemType());
                currentItem = items.getLast();
            }
        }

        public void interactWith (DialogOwner other, boolean isCellInteraction) {
            if (isCellInteraction) {
                dialog = other.getDialog();
            }
        }

        public void interactWith (Foe other, boolean isCellInteraction) { // common methode for all foe (default methode of child class call super's interaction methode)
            if (canHit()) {
                if (currentItem.ELEMENT_TYPE == null){
                    other.takeDamage(damage);
                }
                else {
                    other.takeDamage(damage, currentItem.ELEMENT_TYPE);
                }
            }
        }

        // specific

        public void interactWith (Door other, boolean isCellInteraction) {
            if (other.getSignal().isOn() && isCellInteraction) {
                door = other; // save collided door to transmit to the game
            }
        }

        public void interactWith (DialogDoor other, boolean isCellInteraction) { // interaction with final door
            if (isCellInteraction && !other.getDialog().isCompleted()) {
                dialog = other.getDialog(); // save dialog to transmit to the game
                if (other.getSignal().isOn()) {
                    door = other; // save collided door to transmit to the game
                }
            }
            other.isColliding();
        }

        public void interactWith (Explosif other, boolean isCellInteraction) {
                if (isCellInteraction) isOnItem = true;
                if (wantsInteraction && isCellInteraction && other.isColactable()) { // need to be on a not active bomb to collect it
                    wantsInteraction = false; // reset for block deposit of the inventory one
                    other.collect();
                    inventory.addPocketItem(ICoopItem.EXPLOSIVE, 1);
                }
                else if (wantsInteraction && !isOnItem && !isInCage) {
                    wantsInteraction = false; // reset for block deposit of one of the inventory
                    other.activate();
                }
        }

        public void interactWith (Orb other, boolean isCellInteraction) {
            if (isCellInteraction) {
                interactWith((ElementalItem) other, isCellInteraction);
                interactWith((DialogOwner) other, isCellInteraction);
                elementImunity = other.getElementType();
                /*dialog = other.getDialog();
                other.collect(elementType);*/
            }
        }

        public void interactWith (Heart other, boolean isCellInteraction) {
            if (isCellInteraction && !healthBar.isFull()) {
                addHealth(other.getHp());
                interactWith((ICoopCollectable) other, isCellInteraction);
            }
        }

        public void interactWith (PressurePlate other, boolean isCellInteraction) {
            if (isCellInteraction) {
                other.use(true);
            }
        }

        public void interactWith (Levier other, boolean isCellInteraction) {
            if (wantsInteraction) {
                other.use();
            }
            wantsInteraction = false;
        }

        public void interactWith (Staff other, boolean isCellInteraction) {
            if (isCellInteraction){
                other.collect();
                wantsInteraction = false;
                interactWith((ICoopInventoryItem) other, isCellInteraction);
            }
        }

        public void interactWith (Throne other, boolean isCellInteraction) {
            if (isCellInteraction) {
                isSeated = true;
                orientate(other.getOrientation());
            }
        }

        public void interactWith (Chest other, boolean isCellInteraction) {
            if (wantsInteraction) {
                other.toggleChest();
            }
            wantsInteraction = false;
        }

        public void interactWith (Cage other, boolean isCellInteraction) {
            if (isCellInteraction) {
                other.setKeepOpen(false);
            }
            isInCage = !other.isOpen();
        }
    }
}
