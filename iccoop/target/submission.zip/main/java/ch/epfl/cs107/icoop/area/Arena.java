package ch.epfl.cs107.icoop.area;

import ch.epfl.cs107.icoop.ICoopBehaviour;
import ch.epfl.cs107.icoop.actor.*;
import ch.epfl.cs107.icoop.actor.characters.DarkLord;
import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;
import ch.epfl.cs107.icoop.actor.decorComponent.Obstacle;
import ch.epfl.cs107.icoop.actor.decorComponent.Rock;
import ch.epfl.cs107.icoop.actor.decorComponent.Teleporter;
import ch.epfl.cs107.icoop.actor.items.Clef;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.engine.actor.Background;
import ch.epfl.cs107.play.engine.actor.Foreground;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.signal.logic.And;
import ch.epfl.cs107.play.signal.logic.Logic;

public class Arena extends ICoopArea{

    private static final ICoopPlayer.ElementType FIRE = ElementEntity.ElementType.FIRE;
    private static final ICoopPlayer.ElementType WATER = ElementEntity.ElementType.WATER;
    protected final static DiscreteCoordinates[] playersSpawnPositions = { // protected because it is needed in other classes and the getters cannot be static
            new DiscreteCoordinates(4,5), new DiscreteCoordinates(14,15)};
    public Arena(){
        setAreaSignal(Logic.FALSE);
    }


    public void createArea() {
        // map
        registerActor(new Background(this));
        registerActor(new Foreground(this));

        // logics
        Clef fireKey = new Clef(this, new DiscreteCoordinates(9, 4), FIRE);
        registerActor(fireKey);
        Clef waterKey = new Clef(this, new DiscreteCoordinates(9, 16), WATER);
        registerActor(waterKey);
        And keys = new And(fireKey, waterKey);

        // obstacles & rocks
        for (int x = 0; x < getWidth(); ++x) {
            for (int y = 0; y < getHeight(); ++y) {
                ICoopBehaviour.CellType cellType = getCellType(new DiscreteCoordinates(x, y));
                if (cellType == ICoopBehaviour.CellType.ROCK){
                    registerActor(new Rock(this, new DiscreteCoordinates(x, y)));
                }
                else if (cellType== ICoopBehaviour.CellType.OBSTACLE){
                    registerActor(new Obstacle(this, new DiscreteCoordinates(x, y)));
                }
                else if (cellType== ICoopBehaviour.CellType.DOOR){
                    registerActor(new Teleporter("Spawn", keys, Spawn.playersSpawnPositions, this, new DiscreteCoordinates(10,11)));
                }
            }
        }

        //
        registerActor(new DarkLord(this, Orientation.RIGHT, new DiscreteCoordinates(6, 11)));

        // set area signal
        setAreaSignal(keys);
    }

    @Override
    public String getTitle() {
        return "Arena";
    }

    @Override
    public DiscreteCoordinates[] getPlayerSpawnPositions() {
        return playersSpawnPositions;
    }

    @Override
    public void setExternalLogic(Logic externalLogic) {}
}
