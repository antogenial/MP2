package ch.epfl.cs107.icoop.actor.items;

import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.icoop.handler.ICoopInventoryItem;
import ch.epfl.cs107.icoop.handler.ICoopItem;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class Staff extends ElementalItem implements ICoopInventoryItem {

    public final static float SHOOT_FREQUENCY = 0.4f;
    private final static int ANIMATION_DURATION = 32;
    private Animation sprite;
    private ICoopItem itemType;

    public Staff(Area area, DiscreteCoordinates position, ElementType elementType) {
        super(area, position, Orientation.UP, false, elementType);

        sprite = new Animation("icoop/staff_" + elementType.name().toLowerCase() , 8, 2, 2, this,
                32, 32, new Vector(-0.5f, 0), ANIMATION_DURATION/8, true);

        switch (elementType) {
            case ElementType.FIRE:
                itemType = ICoopItem.FIRESTAFF;
                break;

            case ElementType.WATER:
                itemType = ICoopItem.WATERSTAFF;
                break;
        }
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        sprite.update(deltaTime);
    }

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    // "Interactable" overrides

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }

    @Override
    public ICoopItem getItemType() {
        return itemType;
    }

    @Override
    public int getPocketId() {
        return 0;
    }

    @Override
    public String getName() {
        return "Staff";
    }
}
