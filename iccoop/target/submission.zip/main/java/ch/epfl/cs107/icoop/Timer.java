package ch.epfl.cs107.icoop;

public class Timer {

    private final float MAX_PERIOD;
    private float timer;
    private boolean pause = false;

    public Timer(float period){
        MAX_PERIOD = period;
        timer = MAX_PERIOD;
    }
    public void update(float deltaTime) {
        if (!pause){
            timer -=  deltaTime;
            if (isOver()) setNull();
        }
    }

    public void reset() {
        timer = MAX_PERIOD;
    }

    public void setNull(){
        timer = 0;
    }

    public void pause(){
        pause = true;
    }

    public void resume(){
        pause = false;
    }

    public boolean isOver() {
        return timer <= 0;
    }

    public boolean isPaused(){
        return !pause;
    }

    public float getTimeLeft(){
        return timer;
    }
}
