package ch.epfl.cs107.icoop;

import ch.epfl.cs107.icoop.actor.*;
import ch.epfl.cs107.icoop.actor.characters.Foe;
import ch.epfl.cs107.icoop.actor.decorComponent.ElementalWall;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.area.AreaBehavior;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Window;


public class ICoopBehaviour extends AreaBehavior {


    public ICoopBehaviour(Window window, String name) {
        super(window, name);
        int height = getHeight();
        int width = getWidth();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                CellType type = CellType.toType(getRGB(height - 1 - y, x));
                setCell(x, y, new ICoopCell(x, y, type));
            }
        }
    }

    public boolean isCellEmpty(DiscreteCoordinates cellPos){
        return  ((ICoopCell)getCell(cellPos.x, cellPos.y)).isEmpty();
    }

    public boolean doesCellContain(DiscreteCoordinates cellPos, Class<?> clazz){
        return  ((ICoopCell)getCell(cellPos.x, cellPos.y)).doesContain(clazz);
    }

    public CellType getCellType(DiscreteCoordinates cellPos){
        return  ((ICoopCell)getCell(cellPos.x, cellPos.y)).getType();
    }

    public enum CellType {

        NULL(0, false, false, false),
        WALL(-16777216, false, false, false),
        IMPASSABLE(-8750470, false, true, false),
        INTERACT(-256, true, true, false),
        DOOR(-195580, true, true, false),
        WALKABLE(-1, true, true, false),
        ROCK(-16777204, true, true, true),
        OBSTACLE(-16723187, true, true, true);

        final int type;
        final boolean isWalkable;
        final boolean canFly;
        final boolean constructable;

        CellType(int type, boolean isWalkable, boolean canFly, boolean constructable) {
            this.type = type;
            this.isWalkable = isWalkable;
            this.canFly = canFly;
            this.constructable = constructable;
        }

        public static CellType toType(int type) {
            for (CellType ict : CellType.values()) {
                if (ict.type == type) {
                    return ict;
                }
            }
            return NULL;
        }
    }

    public class ICoopCell extends Cell {

        private final CellType type;

        public ICoopCell(int x, int y, CellType type) {
            super(x, y);
            this.type = type;
        }


        @Override
        protected boolean canLeave(Interactable entity) {
            return true;
        }

        @Override
        protected boolean canEnter(Interactable entity) {
            if (entity instanceof Unstoppable){
                return ((Unstoppable)entity).unstoppable();
            }
            for (Interactable interactable : entities) {
                // if:
                //      the cell contains an interactable who occupies that  cell
                //      OR
                //      the interactable is an active ElementalWall
                //      AND
                //      the entity (that wants to enter the cell) is a Foe
                //      OR
                //      the entity's element type is different from the walls element type

                if (interactable.takeCellSpace() ||
                    // elemental wall management
                    (
                        interactable instanceof ElementalWall && ((ElementalWall)interactable).isOn() &&
                            (entity instanceof Foe ||
                            (entity instanceof ElementEntity && ((ElementEntity) entity).getElementType() != ((ElementEntity)interactable).getElementType()))
                    )
                )
                {
                    return false;
                }
            }
            return type.isWalkable;
        }

        public boolean isEmpty() {
            return entities.isEmpty();
        }

        public boolean doesContain(Class<?> clazz) {
            if (clazz == null) {
                return false;
            }
            for (Interactable interactable : entities) {
                if (clazz.isAssignableFrom(interactable.getClass())) {
                    return true;
                }
            }
            return false; // No corresponding class
        }

        public CellType getType(){
            return type;
        }

        @Override
        public boolean isCellInteractable() {
            return true;
        }

        @Override
        public boolean isViewInteractable() {
            return false;
        }


        @Override
        public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
            ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);        // A CONFIRMER
        }


        @Override
        public boolean takeCellSpace() {
            return true;

        }
    }

}