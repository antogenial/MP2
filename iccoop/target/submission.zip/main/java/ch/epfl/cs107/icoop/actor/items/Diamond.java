package ch.epfl.cs107.icoop.actor.items;

import ch.epfl.cs107.icoop.actor.decorComponent.Chest;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class Diamond extends ICoopCollectable {

    // animation variables
    private Animation sprite;
    private final static int ANIMATION_DURATION = 12;

    private static float sizeFactor = 0.6f;
    private static int caseSize = 16;

    public Diamond(Area area, DiscreteCoordinates position) {
        this(area, position, null);
    }

    public Diamond(Area area, DiscreteCoordinates position, Chest corespondingChest) {
        super(area, Orientation.UP, position, false, corespondingChest);
        Vector anchor = new Vector((1-sizeFactor)/2.f, (1-sizeFactor)/2.f);
        sprite = new Animation("icoop/myDiamondV2",6, sizeFactor, sizeFactor, this, 16, 16,
                anchor,ANIMATION_DURATION / 4, true);
    }

    // Actor overrides
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        sprite.update(deltaTime);
    }
    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    // Interactable overrides

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }

    private static DiscreteCoordinates adaptPos(DiscreteCoordinates pos){
        int margin = ((int)(caseSize*0.5f*sizeFactor)*100)/100; // round to 2 decimal
        return new DiscreteCoordinates(pos.x+ margin, pos.y+margin);
    }
}
