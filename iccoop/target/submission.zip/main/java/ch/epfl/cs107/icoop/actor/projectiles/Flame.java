package ch.epfl.cs107.icoop.actor.projectiles;

import ch.epfl.cs107.icoop.actor.ElementEntity;
import ch.epfl.cs107.icoop.actor.Explosif;
import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;
import ch.epfl.cs107.icoop.actor.decorComponent.ElementalWall;
import ch.epfl.cs107.icoop.actor.decorComponent.Rock;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.window.Canvas;

public class Flame extends Projectile implements ElementEntity {

    // animartion
    private Animation sprite;
    // attack
    private int DAMAGE = 1;
    // other
    private final static ElementEntity.ElementType elementType = ElementEntity.ElementType.FIRE;
    private final FlameInteractionHandler flameInteractionHandler = new FlameInteractionHandler();

    public Flame(Area owner, Orientation orientation, DiscreteCoordinates coordinates, int speed, int distanceMax){
        super(owner, orientation, coordinates, speed, distanceMax);
        // animation
        sprite = new Animation("icoop/fire", 7, 1, 1, this , 16, 16, 4, true);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        sprite.update(deltaTime);
    }

    @Override
    public void collision() {} // redefined as null because continues in a straight line in any case

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    @Override
    public void interactWith(Interactable other, boolean isCellInteraction) {
        other.acceptInteraction(flameInteractionHandler, isCellInteraction);
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }

    @Override
    public ElementType getElementType() {
        return elementType;
    }

    private class FlameInteractionHandler implements ICoopInteractionVisitor {

        public void interactWith(ICoopPlayer other, boolean isCellInteraction) {
            if (isCellInteraction) {
                other.takeDamage(DAMAGE, elementType);
            }
        }

        public void interactWith(Explosif other, boolean isCellInteraction) {
            if (isCellInteraction){
                other.activate();
            }
        }

        public void interactWith(ElementalWall other, boolean isCellInteraction) {
            if (isCellInteraction){
                other.removeFromArea();
            }
        }
        public void interactWith(Rock other, boolean isCellInteraction) {
            if (isCellInteraction){
                other.removeFromArea();
            }
        }
    }
}
