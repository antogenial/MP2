package ch.epfl.cs107.icoop.area;

import ch.epfl.cs107.icoop.ICoopBehaviour;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Window;

import static java.lang.Math.max;

public abstract class ICoopArea extends Area implements Logic {//implements DialogHandler {
    public final static float DEFAULT_SCALE_FACTOR = 13f;
    private float cameraScaleFactor = DEFAULT_SCALE_FACTOR;
    private final int MOVE_DURATION = 8;
    private ICoopBehaviour areaBehaviour;
    private Logic areaSingal;


    protected abstract void createArea();

    // "Playable" overrides

    @Override
    public boolean begin(Window window, FileSystem fileSystem) {
        if (super.begin(window, fileSystem)) {
             areaBehaviour = new ICoopBehaviour(window, getTitle());
            setBehavior(areaBehaviour);
            createArea();
            return true;
        }
        return false;
    }

    // "Area" overrides

    @Override
    public boolean isViewCentered() {
        return true;
    }
    @Override
    public final float getCameraScaleFactor() {
        return cameraScaleFactor;
    }

    // "Logic" overrides

    @Override
    public boolean isOn() {
        return areaSingal.isOn();
    }
    @Override
    public boolean isOff() {
        return areaSingal.isOff();
    }

    // Getters

    public int getMOVE_DURATION(){
        return MOVE_DURATION;
    }

    public abstract DiscreteCoordinates[] getPlayerSpawnPositions();

    // Setters

    public void setCameraScaleFactor(float playersAverageDistance) {
        cameraScaleFactor = (int) max(DEFAULT_SCALE_FACTOR, DEFAULT_SCALE_FACTOR * 0.75 + playersAverageDistance / 2);
    }
    public void setAreaSignal(Logic areaSingal){
        this.areaSingal = areaSingal;
    }

    public boolean isCellEmpty(DiscreteCoordinates cellPos){
        return areaBehaviour.isCellEmpty(cellPos);
    }

    public boolean doesCellContain(DiscreteCoordinates cellPos, Class<?> clazz){
        return areaBehaviour.doesCellContain(cellPos, clazz);
    }

    public ICoopBehaviour.CellType getCellType(DiscreteCoordinates cellPos){
        return areaBehaviour.getCellType(cellPos);
    }

    public abstract void setExternalLogic(Logic externalLogic);
}
