package ch.epfl.cs107.icoop.handler;

import ch.epfl.cs107.play.areagame.handler.InventoryItem;

public interface ICoopInventoryItem extends InventoryItem {
    ICoopItem getItemType();
}
