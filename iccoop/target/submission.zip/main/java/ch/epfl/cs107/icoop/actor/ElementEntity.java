package ch.epfl.cs107.icoop.actor;

import ch.epfl.cs107.icoop.KeyBindings;
import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;

import static ch.epfl.cs107.icoop.KeyBindings.BLUE_PLAYER_KEY_BINDINGS;
import static ch.epfl.cs107.icoop.KeyBindings.RED_PLAYER_KEY_BINDINGS;

public interface ElementEntity { // Entity with element type

    public static enum ElementType {
        // types
        FIRE("red", "icoop/player"),
        WATER( "blue", "icoop/player2");

        // vars
        public final String COLOR;
        public final String PLAYER_NAME;

        ElementType(String color, String playerName) {
            COLOR = color;
            PLAYER_NAME = playerName;
        }

        public static ICoopPlayer.ElementType getType(String name) {
            for (ICoopPlayer.ElementType type : ICoopPlayer.ElementType.values()) {
                if (type.PLAYER_NAME.equals(name)) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Incorrect file name : " + name); //
        }

        @Override
        public String toString() {
            // keep capital in first pos
            return name().substring(0, 1).toUpperCase() + name().substring(1).toLowerCase();
        }
    }

    ElementType getElementType();
}
