package ch.epfl.cs107.icoop.actor.characters;

import ch.epfl.cs107.icoop.actor.DialogOwner;
import ch.epfl.cs107.icoop.actor.ElementEntity;
import ch.epfl.cs107.icoop.actor.Health;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.Updatable;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.engine.actor.Graphics;
import ch.epfl.cs107.play.engine.actor.OrientedAnimation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.Transform;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static ch.epfl.cs107.play.math.Orientation.*;
import static ch.epfl.cs107.icoop.actor.ElementEntity.ElementType;

public class DarkLord extends Foe{

    // health
    private final static int MAX_LIFE = 10;
    private Health healthBar;
    // animation variables
    private final static int ANIMATION_DURATION = 12;
    private final static Orientation[] orders = {DOWN , RIGHT , UP, LEFT};
    private final Graphics[] animations = new Graphics[3];
    private Graphics sprite;

    // attack
    private static int FieldOfViewRay = 3;
    // interaction variable
    private final DarkLordInteractionHandler darkLordInteractionHandler = new DarkLordInteractionHandler();
    private int damage = 1;


    public DarkLord(Area owner, Orientation orientation, DiscreteCoordinates coordinates, ElementEntity.ElementType... vulnerability) {
        super(owner, orientation, coordinates, vulnerability);
        // animation
        healthBar = new Health(this, Transform.I.translated(0, 2f), MAX_LIFE, false);
        Vector anchor =  new Vector(-0.5f, 0);
        animations[0] = construcDeathAnimation(this);
        animations[1] = new OrientedAnimation("icoop/darkLord", ANIMATION_DURATION/3, this, anchor, orders, 4, 2,
                2, 32, 32, true);
        animations[2] = new OrientedAnimation("icoop/darkLord.spell", ANIMATION_DURATION/3, this, anchor, orders, 4, 2,
                2, 32, 32, false);
        autoSelectAnimation();
    }

    public void autoSelectAnimation() {
        //if (sprite != animations[state.ANIMATION_INDEX]){
            //if (sprite instanceof  OrientedAnimation) ((OrientedAnimation)sprite).reset(); // insanceof requests because reset is common methode but not of super
            //else if (sprite instanceof Animation) ((Animation)sprite).reset();
            sprite = animations[1];
        //}
    }

    private DiscreteCoordinates getFrontCell(){
       return getCurrentMainCellCoordinates().jump(getOrientation().toVector());
    }

    private void updateAnimation(float deltaTime){
        ((Updatable) sprite).update(deltaTime);
        autoSelectAnimation();
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
    }

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
        if (!isDead()) { // not drawing health bar during vanish
            healthBar.draw(canvas);
        }
    }

    @Override
    public int getMAX_LIFE() {
       return MAX_LIFE;
    }

    @Override
    public int getHealthPoint() {
        return healthBar.getHealthPoints();
    }

    @Override
    public boolean isCellInteractable() {
        return true;
    }

    @Override
    public boolean isViewInteractable() {
        return true;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor) v).interactWith(this, isCellInteraction);
    }

    @Override
    public List<DiscreteCoordinates> getFieldOfViewCells() { // see in strech line on x cases
            ArrayList<DiscreteCoordinates> fieldOfView = new ArrayList<>();
            for (int x = -FieldOfViewRay; x < FieldOfViewRay; ++x) {
                for (int y = -FieldOfViewRay; y < FieldOfViewRay; ++y) {
                    getCurrentMainCellCoordinates().jump(new Vector(x, y));
                    fieldOfView.add(getCurrentMainCellCoordinates().jump(new Vector(x, y)));
                }
            }
            return fieldOfView;
    }

    @Override
    public boolean wantsCellInteraction() {
        return true;
    }

    @Override
    public boolean wantsViewInteraction() {
        return true;
    }

    @Override
    public void interactWith(Interactable other, boolean isCellInteraction) {
        other.acceptInteraction(darkLordInteractionHandler, isCellInteraction);
    }

    @Override
    public boolean interactWith() {
        return false;
    }

    @Override
    public void takeDamage(int damage) {
        healthBar.decrease(damage);
    }

    @Override
    public void takeDamage(int damage, ElementEntity.ElementType type) {
        takeDamage(damage);
    }

    @Override
    public void addHealth(int hp) {
        healthBar.increase(hp);
    }

    @Override
    public void addHealth(int hp, ElementEntity.ElementType type) {
        healthBar.increase(hp);
    }

    @Override
    public boolean isDead() {
        return healthBar.isOff();
    }

    private class DarkLordInteractionHandler implements ICoopInteractionVisitor {

        public void interactWith(ICoopPlayer other, boolean isCellInteraction) {
            if (Objects.equals(other.getCurrentCells().getFirst(), getFrontCell())){ //
                other.takeDamage(damage);
            }
        }
    }
}
