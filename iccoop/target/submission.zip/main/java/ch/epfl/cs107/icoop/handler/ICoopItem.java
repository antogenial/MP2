package ch.epfl.cs107.icoop.handler;

import ch.epfl.cs107.icoop.actor.ElementEntity;
import ch.epfl.cs107.play.areagame.handler.InventoryItem;


public enum ICoopItem implements InventoryItem {
    // types
    SWORD("icoop/sword.icon", null),
    FIREKEY( "icoop/key_red", ElementEntity.ElementType.FIRE),
    WATERKEY( "icoop/key_blue", ElementEntity.ElementType.WATER),
    FIRESTAFF("icoop/staff_fire.icon", ElementEntity.ElementType.FIRE),
    WATERSTAFF("icoop/staff_water.icon", ElementEntity.ElementType.WATER),
    EXPLOSIVE("icoop/explosive",  null);

    // variables
    final String sprite;
    public final ElementEntity.ElementType ELEMENT_TYPE;

    ICoopItem(String spriteName, ElementEntity.ElementType elementType) {
        this.sprite = spriteName;
        ELEMENT_TYPE = elementType;
    }

    // "InventoryItem" overrides
    @Override
    public int getPocketId() {
        return 0;
    }
    @Override
    public String getName() {
        return "";
    }
}
