package ch.epfl.cs107.icoop.actor.decorComponent;

import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.RPGSprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.window.Canvas;

import java.util.Collections;
import java.util.List;

public class Chest extends AreaEntity {

    private final static int IMAGE_SIZE = 16;
    private int fullThreshold;
    private int amount = 0;
    private RPGSprite[] sprites = new RPGSprite[4];
    private RPGSprite sprite;

    private boolean isClose = false;

    /**
     * Default AreaEntity constructor
     *
     * @param area        (Area): Owner area. Not null
     * @param position    (DiscreteCoordinate): Initial position of the entity in the Area. Not null
     * @param fileName    (DiscreteCoordinate): Srpite name. Not null
     * @param fullThreshold    (DiscreteCoordinate): Number ofellement for display this full. Not null
     */
    public Chest(Area area, DiscreteCoordinates position, String fileName, int fullThreshold) {
        super(area, Orientation.UP, position);
        fullThreshold = fullThreshold;
        for (int i = 0; i < sprites.length; i++) {
            sprites[i] = new RPGSprite(fileName, 1, 1, this , new RegionOfInterest(i * IMAGE_SIZE, 0, IMAGE_SIZE, IMAGE_SIZE));
        }
    }

    public void toggleChest(){
        isClose = !isClose;
    }

    public void addElement(){
        addElement(1);
    }

    public void addElement(int numberOfelelement){
        amount += numberOfelelement;
    }

    public void setFullThreshold(int newfullThreshold){
        fullThreshold = newfullThreshold;
    }

    @Override
    public void update(float deltaTime) {
        if (isClose){
            choseSprite(0);
        }
        else if (amount < fullThreshold/2.0 ){
            choseSprite(1);
        }
        else if (amount <  fullThreshold){
            choseSprite(2);
        }
        else{ // amount >= FULL_THRESHOLD
            choseSprite(3);
        }
    }

    private void choseSprite(int index){ // chose select sprite by index
        sprite = sprites[index];
    }

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    // AreaEntity
    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }

    @Override
    public boolean takeCellSpace() {
        return true;
    }

    @Override
    public boolean isCellInteractable() {
        return true;
    }

    @Override
    public boolean isViewInteractable() { // open or close the chest close to him but not on
        return true;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }
}
