package ch.epfl.cs107.icoop.actor;

import ch.epfl.cs107.play.engine.actor.Dialog;

public interface DialogOwner {
    public Dialog getDialog();
}
