package ch.epfl.cs107.icoop.actor;

import ch.epfl.cs107.icoop.Timer;
import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;
import ch.epfl.cs107.icoop.actor.decorComponent.ElementalWall;
import ch.epfl.cs107.icoop.actor.decorComponent.Mecanisme;
import ch.epfl.cs107.icoop.actor.decorComponent.PressurePlate;
import ch.epfl.cs107.icoop.actor.decorComponent.Rock;
import ch.epfl.cs107.icoop.actor.items.Coin;
import ch.epfl.cs107.icoop.actor.items.Diamond;
import ch.epfl.cs107.icoop.actor.items.ICoopCollectable;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.icoop.handler.ICoopInventoryItem;
import ch.epfl.cs107.icoop.handler.ICoopItem;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.actor.Interactor;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.window.Canvas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static ch.epfl.cs107.play.engine.actor.Sprite.extractSprites;
import static ch.epfl.cs107.play.math.Orientation.*;

public class Explosif extends ICoopCollectable implements Interactor, ICoopInventoryItem {

    // sprites current parameters
    private final static int ANIMATION_DURATION = 24;
    private final static int IMAGE1_SIZE = 16;
    private final static int IMAGE2_SIZE = 32;
    private final int SIZE = 1;

    // attributes
    private final int DAMAGE = 3;
    private Timer timer;
    private Animation sprite;
    private Animation explosiveSrpites, explosionSrpites;
    private Explosif.ExplosifInteractionHandler explosifInteractionHandler = new Explosif.ExplosifInteractionHandler();
    private final ICoopItem ITEM_TYPE = ICoopItem.EXPLOSIVE;

    // state's variables
    private boolean active = false, exploded = false;
    // !active && !exploded => normal state, active && !exploded => flashing state & waiting for explosion
    // active && exploded => is exsploding: animation and damage, !active && exploded => already exploded: not drawn

    public Explosif(Area area, DiscreteCoordinates position) {
        this(area, position, 1.5f);
    }

    public Explosif(Area area, DiscreteCoordinates position, float timeBeforeExplosion) {
        super(area, Orientation.UP, position, true);
        // sprites init
        explosiveSrpites = new Animation("icoop/explosive", 2, SIZE, SIZE, this ,
                IMAGE1_SIZE, IMAGE1_SIZE, ANIMATION_DURATION/6, true);
        explosionSrpites = new Animation("icoop/explosion_reversed", 7, SIZE, SIZE, this ,
                IMAGE2_SIZE, IMAGE2_SIZE, ANIMATION_DURATION/10, false);
        sprite = explosiveSrpites;
        // other vars
        this.timer = new Timer(timeBeforeExplosion);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        if (active) {
            timer.update(deltaTime);
            if (timer.isOver()){
                startExsplosion();
                if (sprite.isCompleted()){
                    active = false;
                }
            }
            sprite.update(deltaTime);
        }
        else {
            sprite.reset();
        }
        if (!active && exploded) {
            super.destroy();
        }
    }

    public void startExsplosion(){
        if (!exploded && timer.isOver()){
            sprite = explosionSrpites;
        }
        exploded = true;
    }

    public void activate() {
        active = true;
    }

    public void draw(Canvas canvas) {
            sprite.draw(canvas);
    }

    // 4 states
    public boolean isColactable(){
        return !active && !exploded;
    }

    public boolean isActivate(){
        return active && ! exploded;
    }

    public boolean isExploding(){
        return active && exploded;
    }

    public boolean isExploded(){
        return !active && exploded;
    }

    // ICoopColecatbale
    @Override
    public void destroy(){
        activate();
    }
    // "Interactable" implemented methods
    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }
    @Override
    public boolean takeCellSpace() {
        return false;
    }

    @Override
    public boolean isCellInteractable() {
        return (!active || !exploded);
    }

    @Override
    public boolean isViewInteractable() {
        return (!active || !exploded) ;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor)v).interactWith(this , isCellInteraction);
    }


    // "Interactor" implemented methods

    @Override
    public List<DiscreteCoordinates> getFieldOfViewCells() {
        return new ArrayList<>(java.util.Arrays.asList(
                getCurrentMainCellCoordinates().jump(LEFT.toVector()),
                getCurrentMainCellCoordinates().jump(RIGHT.toVector()),
                getCurrentMainCellCoordinates().jump(UP.toVector()),
                getCurrentMainCellCoordinates().jump(DOWN.toVector())));
    }

    @Override
    public boolean wantsCellInteraction() {
        return  true; //active && exploded;
    }

    @Override
    public boolean wantsViewInteraction() {
        return active && exploded;
    }

    @Override
    public void interactWith(Interactable other, boolean isCellInteraction) {
            other.acceptInteraction(explosifInteractionHandler, isCellInteraction);
    }


    // "InventoryItem" implemented methods

    @Override
    public int getPocketId() {
        return 0;
    }

    @Override
    public String getName() {
        return "Explosif";
    }

    @Override
    public ICoopItem getItemType() {
        return ITEM_TYPE;
    }


    private class ExplosifInteractionHandler implements ICoopInteractionVisitor {

        public void interactWith(Rock other, boolean isCellInteraction) {
            if (active && exploded) {
                other.removeFromArea();
            }
        }

        public void interactWith(ICoopPlayer other, boolean isCellInteraction) {
            if (isExploding()) {
                other.takeDamage(DAMAGE);
            }
        }

        public void interactWith(Explosif other, boolean isCellInteraction) {
            if (isExploding()) {
                interactWith((ICoopCollectable) other, isCellInteraction);
                //other.activate();
            }
        }

        public void interactWith(ElementalWall other, boolean isCellInteraction) {
            if (isExploding()) {
                other.removeFromArea();
            }
        }

        public void interactWith (ICoopCollectable other, boolean isCellInteraction) {
            if (isExploding()) {
                other.destroy();
            }
        }

        public void interactWith (PressurePlate other, boolean isCellInteraction) {
            if (isCellInteraction) {
                other.use(true);
            }
        }

        public void interactWith (Coin other, boolean isCellInteraction) {
            interactWith((ICoopCollectable) other, isCellInteraction);
        }

        public void interactWith (Diamond other, boolean isCellInteraction) {
            interactWith((ICoopCollectable) other, isCellInteraction);
        }

    }
}
