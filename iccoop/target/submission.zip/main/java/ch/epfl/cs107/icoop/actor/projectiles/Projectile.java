package ch.epfl.cs107.icoop.actor.projectiles;

import ch.epfl.cs107.icoop.actor.Unstoppable;
import ch.epfl.cs107.play.areagame.actor.Interactor;
import ch.epfl.cs107.play.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.window.Canvas;

import java.util.Collections;
import java.util.List;

public abstract class Projectile extends MovableAreaEntity implements Interactor, Unstoppable {

    // movement variables
    public final static int MOVE_DURATION = 12;
    private final DiscreteCoordinates START_POS;
    private final int DISTANCE_MAX;
    private final int SPEED;
    // other
    private boolean collision = false;
    private int stoppedCounter = 0; // counter to check if projectile is stopped

    public Projectile(Area owner, Orientation orientation, DiscreteCoordinates coordinates, int speed, int distanceMax){
        super(owner, orientation, coordinates);
        START_POS = coordinates;
        DISTANCE_MAX = distanceMax;
        SPEED = speed;
    }

    @Override
    public void draw(Canvas canvas) {}

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        // remove if "collision" or distance max is reached
        if (collision || DiscreteCoordinates.distanceBetween(START_POS, getCurrentMainCellCoordinates()) >= DISTANCE_MAX) {
            removeFromArea();
        }
        else if (!move(MOVE_DURATION/SPEED)) isStopped(); // try to delete if movement is blocked
        else stoppedCounter = 0; // resets counter if it was a momentaneous stop
    }

    private void removeFromArea(){// call for delete element
        getOwnerArea().unregisterActor(this);
    }

    private void isStopped(){ // when called determines if the projectile has stopped because of the imprecision or if it has really collided with something
        ++stoppedCounter;
        if (stoppedCounter > (MOVE_DURATION/SPEED)-1){ // verify if movement is really blocked
            removeFromArea();
        }
    }

    public void collision() { // called when a projectile collides on an element
        collision = true;
    }

    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }

    @Override
    public List<DiscreteCoordinates> getFieldOfViewCells() {
        return List.of();
    }

    @Override
    public boolean wantsCellInteraction() {
        return true;
    }

    @Override
    public boolean wantsViewInteraction() {
        return false;
    }

    @Override
    public boolean takeCellSpace() {
        return false;
    }

    @Override
    public boolean isCellInteractable() {
        return false;
    }

    @Override
    public boolean isViewInteractable() {
        return false;
    }


}