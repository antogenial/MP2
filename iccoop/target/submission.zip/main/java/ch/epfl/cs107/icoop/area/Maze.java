package ch.epfl.cs107.icoop.area;

import ch.epfl.cs107.icoop.actor.*;
import ch.epfl.cs107.icoop.actor.characters.BombFoe;
import ch.epfl.cs107.icoop.actor.characters.HellSkull;
import ch.epfl.cs107.icoop.actor.characters.ICoopPlayer;
import ch.epfl.cs107.icoop.actor.decorComponent.*;
import ch.epfl.cs107.icoop.actor.items.Heart;
import ch.epfl.cs107.icoop.actor.items.Staff;
import ch.epfl.cs107.play.engine.actor.Background;
import ch.epfl.cs107.play.engine.actor.Foreground;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.signal.logic.And;
import ch.epfl.cs107.play.signal.logic.Logic;


public class Maze extends ICoopArea{

    private static final ICoopPlayer.ElementType FIRE = ElementEntity.ElementType.FIRE;
    private static final ICoopPlayer.ElementType WATER = ElementEntity.ElementType.WATER;
    protected final static DiscreteCoordinates[] playersSpawnPositions = { // protected because it is needed in other classes and the getters cannot be static
            new DiscreteCoordinates(2,39), new DiscreteCoordinates(3,39)};
            // to spawn closer to the door to test the last area
            //new DiscreteCoordinates(15,6), new DiscreteCoordinates(15,7)};

    public void createArea() {
        // map
        registerActor(new Background(this));
        registerActor(new Foreground(this));

        // logic
        Mecanisme pressurePlate = new PressurePlate(this, new DiscreteCoordinates(6, 33));
        registerActor(pressurePlate);
        Mecanisme levier = new Levier(this, new DiscreteCoordinates(9, 25));
        registerActor(levier);
        Staff fireStaff = new Staff(this,new DiscreteCoordinates(13, 2), FIRE);
        registerActor(fireStaff);
        Staff waterStaff= new Staff(this,new DiscreteCoordinates(8, 2), WATER);
        registerActor(waterStaff);// set area signal
        And staffsTaken = new And(fireStaff, waterStaff);

        // doors
        registerActor(new Door("Arena", staffsTaken, Arena.playersSpawnPositions, this,
                new DiscreteCoordinates(19, 6), new DiscreteCoordinates(19, 7)));

        // always activated walls
        registerActor(new ElementalWall(this, new DiscreteCoordinates(4,35), Orientation.LEFT, WATER));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(4,36), Orientation.LEFT, WATER));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(2,34), Orientation.DOWN, FIRE));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(3,34), Orientation.DOWN, FIRE));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(5,24), Orientation.DOWN, WATER));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(6,24), Orientation.DOWN, WATER));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(8,4), Orientation.DOWN, WATER));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(13,4), Orientation.DOWN, FIRE));

        // deactivatable walls
        registerActor(new ElementalWall(this, new DiscreteCoordinates(6,35), Orientation.LEFT, FIRE, pressurePlate));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(6,36), Orientation.LEFT, FIRE, pressurePlate));
        registerActor(new ElementalWall(this, new DiscreteCoordinates(8,21), Orientation.DOWN, FIRE, levier));

        // items
        registerActor(new Heart(this, new DiscreteCoordinates(14, 17)));
        registerActor(new Heart(this, new DiscreteCoordinates(14, 19)));
        registerActor(new Heart(this, new DiscreteCoordinates(15, 18)));
        registerActor(new Heart(this, new DiscreteCoordinates(16, 19)));

        // bomb
        registerActor(new Explosif(this, new DiscreteCoordinates(6, 25)));

        // FOE
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(12,33)));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(12,31)));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(12,29)));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(12,27)));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(12,25)));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(10,32)));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(10,30)));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(10,28)));
        registerActor(new HellSkull(this, Orientation.RIGHT, new DiscreteCoordinates(10,26)));
        registerActor(new BombFoe(this, new DiscreteCoordinates(5,14)));
        registerActor(new BombFoe(this, new DiscreteCoordinates(5,15)));
        registerActor(new BombFoe(this, new DiscreteCoordinates(6,17)));
        registerActor(new BombFoe(this, new DiscreteCoordinates(10,17)));

        // set area signal
        setAreaSignal(staffsTaken);
    }

    // "ICoopArea" overrides
    @Override
    public DiscreteCoordinates[] getPlayerSpawnPositions() {
        return playersSpawnPositions;
    }
    @Override
    public void setExternalLogic(Logic externalLogic) {}

    // "Playable" overrides
    @Override
    public String getTitle() {
        return "Maze";
    }
}
