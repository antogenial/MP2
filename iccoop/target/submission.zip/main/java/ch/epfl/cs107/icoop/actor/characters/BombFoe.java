package ch.epfl.cs107.icoop.actor.characters;

import ch.epfl.cs107.icoop.Timer;
import ch.epfl.cs107.icoop.actor.Explosif;
import ch.epfl.cs107.icoop.actor.Health;
import ch.epfl.cs107.icoop.area.ICoopArea;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.Updatable;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.engine.actor.Graphics;
import ch.epfl.cs107.play.engine.actor.OrientedAnimation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.Transform;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.math.random.RandomGenerator;
import ch.epfl.cs107.play.window.Canvas;

import static ch.epfl.cs107.play.math.Orientation.*;
import static ch.epfl.cs107.icoop.actor.ElementEntity.ElementType;

import java.util.ArrayList;
import java.util.List;

public class BombFoe extends Foe {

    // health
    private final static int MAX_LIFE = 4;
    private Health healthBar;
    // numerical values
    public static int MOVE_DURATION = 12;
    private final static int FIELD_OF_VIEW_CELLS_LENGTH = 3;
    private final static int SIMULATION_STEEP = 24;
    private int steeps = 0; // -1 when simulation steep are finish
    // animation vars
    private final static int ANIMATION_DURATION = 12;
    private final Graphics[] animations = new Graphics[3];
    private Graphics sprite;
    // other management features
    private final static int PORBA_EVENT = 40, PROBA_UNIVER = 100;
    private final BombFoeInteractionHandler bombFoeInteractionHandler = new BombFoeInteractionHandler();
    private static final Orientation[] orders = {DOWN , RIGHT , UP, LEFT};
    private State state;
    private final static float MIN_TIME = 2f, MAX_TIME = 3f;
    private Timer projectilTimer;
    private  boolean canMove = true;

    public BombFoe(Area owner, DiscreteCoordinates coordinates) {
        super(owner, DOWN, coordinates, ElementType.FIRE);

        // animation
        healthBar = new Health(this, Transform.I.translated(0, 2f), MAX_LIFE, false);
        Vector anchor =  new Vector(-0.5f, 0);
        animations[0] = construcDeathAnimation(this);
        animations[1] = new OrientedAnimation("icoop/bombFoe", ANIMATION_DURATION/3, this, anchor, orders, 4, 2,
                    2, 32, 32, true);
        animations[2] = new OrientedAnimation("icoop/bombFoe.protecting", ANIMATION_DURATION/3, this, anchor, orders, 4, 2,
                2, 32, 32, false);

        sprite = animations[1];
        setState(State.NUll);
        initProjectileTimer();
        projectilTimer.setNull();


    }

     public static enum State {
         NUll(null, 1, 1, true),
         IDLE("idle", 1, 1, true),
         ATTACK("atack", 1, 1, true),
         DEFEND("defend",2, 1, false),
         DEAD("dead", 0, 1,false);

         public final String NAME;
         public final int ANIMATION_INDEX;
         public int speed;
         public final boolean CAN_WALK;
         State(String name, int animationIndex, int speed, boolean canWalk) {
             NAME = name;
             ANIMATION_INDEX = animationIndex;
             this.speed = speed;
             CAN_WALK = canWalk;
         }

         @Override
         public String toString() {
             return NAME;
         }
     }

    private void initProjectileTimer() {
        float t = RandomGenerator.getInstance().nextFloat(MIN_TIME , MAX_TIME);
        projectilTimer = new Timer(t);
    }

    private void setState(State state){
        this.state = state;
        autoSelectAnimation();
    }


    // Actor overrides
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
         // start phase
         if (0 <= steeps && steeps < SIMULATION_STEEP){
             setState(State.NUll);
             ++steeps;
         } else if (steeps == SIMULATION_STEEP) {
             steeps = -1;
             setState(State.IDLE);
         }
         // bombing
         projectilTimer.update(deltaTime);
         if (state == State.ATTACK){
             if (!canMove && projectilTimer.isOver()){ // if is good distance of player (and timer is over)
                 DiscreteCoordinates firstFrontCell = getCurrentMainCellCoordinates().jump(getOrientation().toVector()); // get next case
                 if (((ICoopArea)getOwnerArea()).isCellEmpty(firstFrontCell)) { // if cell is empty of interactable
                     Explosif bomb = new Explosif(getOwnerArea(), firstFrontCell, MIN_TIME);
                     getOwnerArea().registerActor(bomb);
                     bomb.activate();
                     setState(State.DEFEND);
                     projectilTimer.reset();
                 }
             }
         }

         // vulnerability
         if (state == State.DEFEND){
             setIsUnvulnerable(true);
             updateAnimation(deltaTime);
         }
         if (getIsUnvulnerable()) {
             getImmunityTimer().update(deltaTime);
             if(getImmunityTimer().isOver()){
                 setIsUnvulnerable(false);
                 setState(State.ATTACK);
                 getImmunityTimer().reset();
             }
         }

         // end life
         if (isDead()) {
             setState(State.DEAD);
             updateAnimation(deltaTime);
             if (((Animation) sprite).isCompleted()) super.removeFromArea();
         }

         // other
         movingManager(deltaTime);
         if (state == State.ATTACK) setState(State.IDLE);
         canMove = true;
    }

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
        if (!isDead()) { // not drawing health bar during vanish
            healthBar.draw(canvas);
        }
    }

    // Private methods

    private void updateAnimation(float deltaTime){
        ((Updatable) sprite).update(deltaTime);
    }

    private void movingManager(float deltaTime){
        if (isDisplacementOccurs()) updateAnimation(deltaTime); // check if already moving
        else if (state.CAN_WALK && (state != State.ATTACK || canMove)){ // check Foe state
            if(state == State.ATTACK){ // if state = ATTACK, move only if second cell is empty
                DiscreteCoordinates secondFrontCell = getCurrentMainCellCoordinates().jump(getOrientation().toVector().mul(2)); // get second cell coordinate
                if (((ICoopArea)getOwnerArea()).isCellEmpty(secondFrontCell)){
                    move(MOVE_DURATION/state.speed);
                }
            }
            else{
                move(MOVE_DURATION/state.speed);
                if (state == State.IDLE) randomOrientationChange(); // try to change orientation if idle state
            }
        }
    }

    private void randomOrientationChange(){
        if (RandomGenerator.getInstance().nextInt(PROBA_UNIVER) <= PORBA_EVENT){ // chance to change direction
            Orientation newOrientation;
            int index;
            do {
                index = RandomGenerator.getInstance().nextInt(orders.length); // select a random direction
                newOrientation = orders[index];
            }
            while (newOrientation == getOrientation()); // reselect if orientation is the same as the current one
            orientate(newOrientation);
        }

    }


    // Public methods

    public void autoSelectAnimation() {
        if (sprite != animations[state.ANIMATION_INDEX]){ // check i current sprite = needed sprite
            if (sprite instanceof  OrientedAnimation) ((OrientedAnimation)sprite).reset(); // insanceof requests because reset is common methode but not of super
            else if (sprite instanceof  Animation) ((Animation)sprite).reset();
            sprite = animations[state.ANIMATION_INDEX];
        }
    }

    public void targeting(DiscreteCoordinates pos){
        Vector vect = getCurrentMainCellCoordinates().toVector().sub(pos.toVector()); // vector between this and target
        Orientation.fromVector(vect);
    }

    // Interactable overrides

    @Override
    public boolean isCellInteractable() {
        return true;
    }
    @Override
    public boolean isViewInteractable() {
        return true;
    }
    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor) v).interactWith(this, isCellInteraction);
    }

    // Interactor overrides

    @Override
    public List<DiscreteCoordinates> getFieldOfViewCells() { // see in strech line on x cases
        if (state == State.ATTACK) return List.of(getCurrentMainCellCoordinates().jump(getOrientation().toVector()));
        else {
            ArrayList<DiscreteCoordinates> fieldOfView = new ArrayList<>();
            for (int i = 0; i < FIELD_OF_VIEW_CELLS_LENGTH; ++i) {
                // iterate and add the next cases x time;
                DiscreteCoordinates pos;
                if (fieldOfView.isEmpty()) pos = getCurrentMainCellCoordinates().jump(getOrientation().toVector());
                else pos = fieldOfView.get(i-1).jump(getOrientation().toVector());
                fieldOfView.add(pos);
            }
            return fieldOfView;
        }
    }
    @Override
    public boolean wantsCellInteraction() {
        return false;
    }
    @Override
    public boolean wantsViewInteraction() {
        return state == State.IDLE || state == State.ATTACK; //true;
    }
    @Override
    public void interactWith(Interactable other, boolean isCellInteraction) {
        other.acceptInteraction(bombFoeInteractionHandler, isCellInteraction);
    }
    @Override
    public boolean interactWith() {
        return false;
    }

    // IDK what overrides

    @Override
    public int getMAX_LIFE() {
        return MAX_LIFE;
    }

    @Override
    public int getHealthPoint() {
        return healthBar.getHealthPoints();
    }


    @Override
    public void takeDamage(int damage) {
        if (!getIsUnvulnerable() || state != State.DEFEND){
            healthBar.decrease(damage);
            setIsUnvulnerable(true);
        }
    }

    @Override
    public void takeDamage(int damage, ElementType type) {
        System.out.println();
        if (isVulnerableTo(type)) takeDamage(damage);
    }

    @Override
    public void addHealth(int hp) {} // can't be treated

    @Override
    public void addHealth(int hp, ElementType type) {
        addHealth(hp); // keep back health independently of type
    }

    @Override
    public boolean isDead() {
        return healthBar.isOff();
    }



    private class BombFoeInteractionHandler implements ICoopInteractionVisitor {

        public void interactWith(ICoopPlayer other, boolean isCellInteraction) {
            if (!isCellInteraction) {
                setState(State.ATTACK);
                DiscreteCoordinates playerPos = other.getCurrentMainCellCoordinates();
                if (DiscreteCoordinates.distanceBetween(getCurrentMainCellCoordinates(), playerPos) <= 2) canMove = false;
                else targeting(other.getCurrentMainCellCoordinates());
            }
        }
    }
}
