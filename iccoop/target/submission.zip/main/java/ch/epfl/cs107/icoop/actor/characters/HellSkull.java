package ch.epfl.cs107.icoop.actor.characters;

import ch.epfl.cs107.icoop.Timer;
import ch.epfl.cs107.icoop.actor.ElementEntity;
import ch.epfl.cs107.icoop.actor.projectiles.Flame;
import ch.epfl.cs107.icoop.handler.ICoopInteractionVisitor;
import ch.epfl.cs107.play.areagame.actor.Interactable;
import ch.epfl.cs107.play.areagame.area.Area;
import ch.epfl.cs107.play.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.engine.Updatable;
import ch.epfl.cs107.play.engine.actor.Animation;
import ch.epfl.cs107.play.engine.actor.Graphics;
import ch.epfl.cs107.play.engine.actor.OrientedAnimation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Orientation;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.math.random.RandomGenerator;
import ch.epfl.cs107.play.window.Canvas;

import static ch.epfl.cs107.play.math.Orientation.*;

import java.util.List;

public class HellSkull extends Foe {

    // health
    private final int MAX_LIFE = 1;
    private int hp = MAX_LIFE;
    // animation
    private final static int ANIMATION_DURATION = 12;
    private final OrientedAnimation mainSprite;
    private final Animation deathAnimatiom;
    private Graphics sprite; // Graphics because common class of Animation and OrientedAnimation
    Orientation[] orders;
    // attack vars
    private final static float MIN = 0.5f, MAX = 3.5f; // min an max timer value
    private final int DAMAGE = 2;
    private Timer projectilTimer;
    private boolean isShooter; // true for shoot fire
    // others
    private final static ElementEntity.ElementType type = ElementEntity.ElementType.FIRE;
    private final HellSkullInteractionHandler hellSkullInteractionHandler = new HellSkullInteractionHandler();

    public HellSkull(Area owner, Orientation orientation, DiscreteCoordinates coordinates){ // is shooter by default
        this(owner, orientation, coordinates, true);
    }

    public HellSkull(Area owner, Orientation orientation, DiscreteCoordinates coordinates, boolean isShooter){
        super(owner, orientation, coordinates, ElementEntity.ElementType.WATER);
        // set values
        this.isShooter = isShooter;
        // animation
        deathAnimatiom = construcDeathAnimation(this);
        orders = new Orientation []{ UP, LEFT , DOWN , RIGHT};
        mainSprite = new OrientedAnimation("icoop/flameskull", ANIMATION_DURATION/3, this , new Vector(-0.5f, -0.5f),
                orders , 3, 2, 2, 32, 32, true);
        sprite = mainSprite;
        //other
        initProjectileTimer();
    }

    private void initProjectileTimer(){
        float t = RandomGenerator.getInstance().nextFloat(MIN , MAX); // random timer value
        projectilTimer = new Timer(t);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        ((Updatable)sprite).update(deltaTime); // transtipage because sprite is register like Graphics but contain instance who implement updatable
        // vulnerability
        if (getIsUnvulnerable()) {
            getImmunityTimer().update(deltaTime);
            if(getImmunityTimer().isOver()){
                setIsUnvulnerable(false);
                getImmunityTimer().reset();
            }
        }
        // projectile launch
        projectilTimer.update(deltaTime);
        if (isShooter && projectilTimer.isOver()){
            DiscreteCoordinates pos = getCurrentMainCellCoordinates().jump(getOrientation().toVector()); // get front cell
            getOwnerArea().registerActor(new Flame(getOwnerArea(), getOrientation(), pos, 2, 8)); // create and register projectile
            initProjectileTimer();
        }
        if (isDead()) {
            sprite = deathAnimatiom;
            if (((Animation) sprite).isCompleted()) super.removeFromArea(); // wait end of vanish animation for unregister
        }
    }

    //Foe
    @Override
    public void takeDamage(int damage) {;
        if (!getIsUnvulnerable()){
            hp = hp - damage;
            setIsUnvulnerable(true);
        }
    }

    @Override
    public void takeDamage(int damage, ElementEntity.ElementType type) {
        if (isVulnerableTo(type)) takeDamage(damage);
    }

    @Override
    public void addHealth(int hp) {} // can't be treated

    @Override
    public void addHealth(int hp, ElementEntity.ElementType type) {
        if (this.type != type) addHealth(hp); // keep back health independently of type
    }

    @Override
    public boolean isDead() {
        return hp <= 0;
    }

    @Override
    public void draw(Canvas canvas) {
        sprite.draw(canvas);
    }

    // Interactable
    @Override
    public boolean takeCellSpace() {
        return false;
    }

    @Override
    public boolean isCellInteractable() {
        return true;
    }

    @Override
    public boolean isViewInteractable() {
        return true;
    }

    @Override
    public int getMAX_LIFE() {
        return MAX_LIFE;
    }

    @Override
    public int getHealthPoint() {
        return hp;
    }

    @Override
    public void acceptInteraction(AreaInteractionVisitor v, boolean isCellInteraction) {
        ((ICoopInteractionVisitor) v).interactWith(this, isCellInteraction);
    }

    @Override
    public boolean interactWith() {
        return false;
    }

    // Interactor

    @Override
    public List<DiscreteCoordinates> getFieldOfViewCells() {
        return List.of();
    }
    @Override
    public boolean wantsCellInteraction() {
        return !isDead();
    }

    @Override
    public boolean wantsViewInteraction() {
        return false;
    }

    @Override
    public void interactWith(Interactable other, boolean isCellInteraction) {
        other.acceptInteraction(hellSkullInteractionHandler, isCellInteraction);
    }

    private class HellSkullInteractionHandler implements ICoopInteractionVisitor {

        public void interactWith(ICoopPlayer other, boolean isCellInteraction) {
            if (isCellInteraction) {
                other.takeDamage(DAMAGE, type);
            }
        }
    }
}
